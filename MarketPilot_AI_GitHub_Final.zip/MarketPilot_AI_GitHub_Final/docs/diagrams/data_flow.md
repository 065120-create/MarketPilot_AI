# MarketPilot AI — Data Flow Diagram

```mermaid
flowchart TD
    subgraph Inputs["1. Ingestion & Pre-processing"]
        UserForm["User Campaign Blueprint<br/>(Brand, Channels, Budget, Geography)"]
        CSV1["Campaign Performance CSV<br/>(Spend, Impressions, Clicks, Revenue)"]
        CSV2["Customer Feedback CSV<br/>(Reviews, Sentiment, Star Ratings)"]
        CSV3["Customer Demographics CSV<br/>(Age, City, Total Spend, LTV)"]
        CSV4["Customer Journey CSV<br/>(Touchpoints, Stages, Drop-offs)"]
    end

    subgraph Sanitation["2. Entity Normalization & Quality Gate"]
        Norm["Spelling & Entity Normalizer<br/>(e.g., 'cocacola' -> 'Coca-Cola')"]
        AuditLog["Input Verification Audit Trail<br/>(User accept / edit / keep original)"]
        DataVal["Data Quality Engine<br/>(Negative spend clip, type validation, auto-fix)"]
    end

    subgraph CoreAnalysis["3. Multi-Agent Computation"]
        CP["Campaign Performance Analyst<br/>• ROAS: Revenue / Spend<br/>• CPA: Spend / Conversions<br/>• CTR: Clicks / Impressions"]
        CV["Customer Voice Analyst<br/>• Sentiment Distribution<br/>• Positive & Negative Drivers"]
        CS["Segmentation Analyst<br/>• RFM Clustering<br/>• K-Means Personas (Champions, Explorers)"]
        CJ["Customer Journey Analyst<br/>• Funnel Conversion Velocity<br/>• Stage Abandonment Points"]
    end

    subgraph OptimizationEngine["4. Mathematical & Strategic Synthesis"]
        ConvexOpt["Budget Optimizer<br/>• ROAS-Weighted Reallocation<br/>• Strict Total Budget Conservation"]
        StratOpt["Campaign Strategist<br/>• Evidence-Backed Recommendations<br/>• RAG Citations & Explainability"]
        GovCheck["Quality Guardian<br/>• Arithmetic Balance Audit<br/>• Risk Concentration Gate (<35%)"]
    end

    subgraph OutputSurfaces["5. Observability & Downstream Action"]
        Dash["Interactive Dashboard (/dashboard.html)<br/>Charts, Metrics, AI Strategy"]
        Sim["What-If Simulator (/scenarios.html)<br/>Real-Time Slider Reallocation"]
        Brief["Executive Briefing (/reports.html)<br/>Printable CMO Report"]
        n8nOut["n8n Cloud Webhook<br/>Google Sheets, Drive, Email"]
    end

    UserForm --> Norm --> AuditLog
    CSV1 & CSV2 & CSV3 & CSV4 --> DataVal
    AuditLog & DataVal --> CP & CV & CS & CJ
    CP & CV & CS & CJ --> ConvexOpt & StratOpt
    ConvexOpt & StratOpt --> GovCheck
    GovCheck --> Dash & Sim & Brief
    GovCheck -->|Human Approval| n8nOut
```
