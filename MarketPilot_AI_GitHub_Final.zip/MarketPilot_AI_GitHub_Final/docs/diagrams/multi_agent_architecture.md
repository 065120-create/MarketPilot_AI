# MarketPilot AI — Multi-Agent Architecture

```mermaid
sequenceDiagram
    autonumber
    actor User as Marketer / Human Lead
    participant Orch as Orchestrator Agent
    participant DataAgents as Data Analytics Agents<br/>(Performance, Voice, Seg, Journey)
    participant RAG as RAG Knowledge Engine
    participant StrategyAgents as Synthesis Agents<br/>(Optimization, Budget, Content)
    participant Quality as Quality Governance Agent
    participant Synth as Executive Synthesis Agent
    participant n8n as n8n Cloud Automation

    User->>Orch: Submit Campaign Blueprint (Brand, Budget, Channels, Goals)
    Orch->>Orch: Dynamic Inspection: Check available datasets & objectives
    
    rect rgb(26, 38, 57)
        Note over Orch,DataAgents: Phase 1: Parallel / Empirical Analytics
        Orch->>DataAgents: Ingest telemetry (Spend, Feedback, Customers, Touchpoints)
        DataAgents-->>Orch: Metrics (ROAS, CPA), Sentiment clusters, RFM personas, Funnel loss
    end

    rect rgb(40, 26, 57)
        Note over Orch,RAG: Phase 2: Domain Knowledge Retrieval
        Orch->>RAG: Query authoritative best practices for identified bottlenecks
        RAG-->>Orch: Marketing frameworks (Marginal returns, Retargeting models)
    end

    rect rgb(26, 57, 45)
        Note over Orch,StrategyAgents: Phase 3: Strategy Formulation
        Orch->>StrategyAgents: Generate prioritized recommendations & convex budget
        StrategyAgents-->>Orch: Allocation schedules & intervention playbooks
    end

    rect rgb(57, 35, 26)
        Note over Orch,Quality: Phase 4: Quality & Risk Reflection Gate
        Orch->>Quality: Audit arithmetic balance, single-channel concentration, evidence grounding
        alt Concentration or Budget Alert Detected
            Quality-->>Orch: REJECT: Feedback with specific constraint violations
            Orch->>StrategyAgents: Recalibrate allocation with strict diversification limits
            StrategyAgents-->>Quality: Revised balanced allocation
            Quality-->>Orch: PASS: 0 constraints violated & zero arithmetic drift
        else All Checks Pass
            Quality-->>Orch: PASS
        end
    end

    Orch->>Synth: Final executive brief compilation & 30-day action roadmap
    Synth-->>User: Complete Strategy Package on Dashboard

    User->>n8n: Human Review & Approval Gate Triggered
    n8n-->>User: Appends to Google Sheets, Archives in Drive, Dispatches Email
```
