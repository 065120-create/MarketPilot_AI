# Render Cloud Deployment & Webhook Integration Architecture

```mermaid
flowchart TD
    subgraph DeveloperWorkstation ["Developer Workstation (Local macOS)"]
        DEV["Developer Workspace<br/>~/Desktop/MarketPilot_AI"]
        GIT_LOCAL["Local Git Repository<br/>main branch"]
        DEV -->|"git push origin main"| GIT_LOCAL
    end

    subgraph GitHubRepo ["GitHub Cloud Version Control"]
        GH["GitHub Remote Repository<br/>shouvikdas/MarketPilot_AI"]
        GIT_LOCAL -->|"HTTPS / SSH Push"| GH
        GH_WEBHOOK["GitHub Auto-Deploy Webhook"]
        GH --> GH_WEBHOOK
    end

    subgraph RenderPlatform ["Render Cloud Platform (render.com)"]
        RENDER_SVC["Render Web Service<br/>Python 3.11/3.13 Runtime<br/>https://marketpilot-ai.onrender.com"]
        BUILD_STEP["Build Step:<br/>pip install -r requirements.txt"]
        START_CMD["Start Command:<br/>uvicorn app.main:app --host 0.0.0.0 --port $PORT"]
        ENV_VARS["Render Environment Variables:<br/>• PORT (dynamic)<br/>• LLM_PROVIDER=gemini<br/>• GOOGLE_API_KEY=AIzaSy...<br/>• N8N_ENABLED=true<br/>• N8N_WEBHOOK_URL=https://...<br/>• MAX_UPLOAD_SIZE_MB=50"]
        
        GH_WEBHOOK -->|"Auto Deploy Trigger"| BUILD_STEP
        BUILD_STEP --> START_CMD
        ENV_VARS --> RENDER_SVC
        START_CMD --> RENDER_SVC
    end

    subgraph PublicInternet ["End Users & Executives"]
        USER["User Web Browser<br/>(Chrome / Safari / Edge)"]
        USER -->|"HTTPS Requests / Static HTML<br/>GET /dashboard.html, POST /api/analyze"| RENDER_SVC
    end

    subgraph LLMProviders ["External LLM APIs"]
        GEMINI["Google Gemini API<br/>gemini-2.0-flash"]
        RENDER_SVC -->|"HTTPS API Calls<br/>(Async LLM Reasoning)"| GEMINI
    end

    subgraph N8NCloud ["n8n Cloud Automation Engine"]
        N8N_HOOK["n8n Webhook Trigger<br/>POST /webhook/marketpilot"]
        N8N_FLOW["Workflow Pipeline:<br/>1. Payload Validation<br/>2. Google Sheets Logger<br/>3. Google Drive Archiver<br/>4. Executive Email Dispatcher"]
        
        RENDER_SVC -->|"POST /api/jobs/{id}/approve<br/>(Structured Campaign Dispatch)"| N8N_HOOK
        N8N_HOOK --> N8N_FLOW
    end

    subgraph GoogleWorkspace ["Enterprise Integration (Google Workspace)"]
        GSHEET["Google Sheets<br/>MarketPilot Campaign Insights"]
        GDRIVE["Google Drive<br/>MarketPilot Reports Folder"]
        GMAIL["Gmail / Corporate SMTP<br/>CMO & Marketing Team Inbox"]
        
        N8N_FLOW -->|"Row Append"| GSHEET
        N8N_FLOW -->|"PDF/Markdown Upload"| GDRIVE
        N8N_FLOW -->|"HTML Campaign Summary"| GMAIL
    end

    classDef host fill:#0a0a1a,stroke:#4361ee,stroke-width:2px,color:#fff;
    classDef cloud fill:#111128,stroke:#06d6a0,stroke-width:2px,color:#fff;
    classDef ext fill:#16213e,stroke:#ff9f1c,stroke-width:2px,color:#fff;

    class DEV,GIT_LOCAL host;
    class GH,RENDER_SVC,BUILD_STEP,START_CMD,ENV_VARS cloud;
    class GEMINI,N8N_HOOK,N8N_FLOW,GSHEET,GDRIVE,GMAIL ext;
```

## Architectural Component Breakdown

1. **Continuous Integration & Deployment (CI/CD)**:
   - Developer pushes tested commits to GitHub repository.
   - Render detects repository updates via GitHub webhooks and initiates automatic builds.
   - Build environment executes dependency resolution via `pip install -r requirements.txt`.

2. **Web Server Runtime**:
   - Render assigns a dynamic port through the `$PORT` environment variable.
   - Uvicorn binds to `0.0.0.0:$PORT` serving both FastAPI REST endpoints and the responsive frontend.

3. **External AI & Automation Decoupling**:
   - **Google Gemini API**: Handles natural language reasoning, narrative generation, and semantic interpretations.
   - **n8n Cloud Webhook**: Decouples campaign approval downstream actions (Sheets, Drive, Email) from the core web service.
   - If n8n Cloud is unreachable, MarketPilot AI continues operating normally with logged fallback warnings.
