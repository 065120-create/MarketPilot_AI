# MarketPilot AI — Quality Governance & Self-Correction Reflection Loop

```mermaid
stateDiagram-v2
    [*] --> Initial_Planning
    Initial_Planning --> Strategy_Agents_Execution: Orchestrator routes agents
    Strategy_Agents_Execution --> Quality_Audit_Gate: Strategy & Budget outputs generated

    state Quality_Audit_Gate <<choice>>
    Quality_Audit_Gate --> Validation_Passed: All checks pass (0 violations)
    Quality_Audit_Gate --> Quality_Rejection: Constraint violated or drift detected

    state Quality_Rejection {
        [*] --> Detect_Violation
        Detect_Violation --> Log_Audit_Reason: e.g. Single-channel concentration > 35%
        Log_Audit_Reason --> Synthesize_Feedback: Formulate structured constraint directives
        Synthesize_Feedback --> [*]
    }

    Quality_Rejection --> Recalibrate_Agent: Enforce reflection loop (Attempt 1 of 2)
    Recalibrate_Agent --> Strategy_Agents_Execution: Re-run with feedback penalty

    Validation_Passed --> Final_Synthesis: 100% Validated Output
    Final_Synthesis --> Human_Review_Gate: Present strategy on Dashboard

    state Human_Review_Gate <<choice>>
    Human_Review_Gate --> Approved_Action: User clicks "Approve & Trigger n8n"
    Human_Review_Gate --> Human_Revision_Loop: User inputs custom revision prompt

    Human_Revision_Loop --> Strategy_Agents_Execution: Swarm reflects with user guidance
    Approved_Action --> [*]: Dispatched to n8n Cloud Webhook
```
