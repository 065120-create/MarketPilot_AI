# MarketPilot AI — Overall System Architecture

```mermaid
graph TD
    subgraph ClientLayer["Frontend Client Layer (HTML5 / Vanilla JS / Chart.js)"]
        UI_Home["Landing Page (index.html)"]
        UI_Dash["Executive Dashboard (dashboard.html)"]
        UI_Camp["Campaign Creator & Normalization (campaign.html)"]
        UI_Upload["Data Upload & Auto-Fix (upload.html)"]
        UI_Swarm["Agent Swarm Observability (agents.html)"]
        UI_Voice["Customer Voice (insights.html)"]
        UI_Seg["Customer Segmentation (segments.html)"]
        UI_Journ["Journey Funnel (journey.html)"]
        UI_Opt["Optimization Engine (optimization.html)"]
        UI_Bud["Budget Allocation (budget.html)"]
        UI_Scen["Scenario Simulator (scenarios.html)"]
        UI_Gov["Human Review & Governance (recommendations.html)"]
        UI_RAG["RAG Knowledge Explorer (rag.html)"]
        UI_Rep["Executive Report Center (reports.html)"]
    end

    subgraph APILayer["FastAPI Application Server (Python 3.11/3.13)"]
        API_Main["FastAPI Router (/api)"]
        StateStore["Thread-Safe In-Memory JobStore"]
        NormEngine["Entity Normalization & Fuzzy Matcher"]
        ValEngine["Data Quality & Anomaly Engine"]
        ScenEngine["What-If Convex Simulator"]
    end

    subgraph AgentSwarm["Autonomous Multi-Agent Swarm"]
        Orchestrator["🧭 Dynamic Orchestrator Agent"]
        Agent_Perf["📈 Campaign Performance Analyst"]
        Agent_Voice["🗣️ Customer Voice & Sentiment Agent"]
        Agent_Seg["👥 Customer Segmentation ML Agent"]
        Agent_Journ["🔄 Customer Journey Funnel Agent"]
        Agent_RAG["📚 Autonomous RAG Retriever"]
        Agent_Opt["⚡ Campaign Optimization Strategist"]
        Agent_Bud["💰 Budget Allocation Optimizer"]
        Agent_Content["✍️ Content Recommendation Specialist"]
        Agent_Quality["🛡️ Quality Governance Guardian (Self-Healing Loop)"]
        Agent_Synth["📋 Executive Synthesis Agent"]
    end

    subgraph KnowledgeLayer["RAG Knowledge Base & Embeddings"]
        ChromaStore["Vector Store (ChromaDB / TF-IDF Fallback)"]
        KB_Docs["10 Markdown Marketing Frameworks"]
    end

    subgraph ExternalAutomation["Downstream Automation (n8n Cloud)"]
        n8n_Webhook["n8n Webhook Node"]
        n8n_Sheets["Google Sheets (Campaign Log)"]
        n8n_Drive["Google Drive (Executive PDF Brief)"]
        n8n_Email["Gmail / SMTP (Executive Notification)"]
    end

    ClientLayer -->|REST / JSON| APILayer
    APILayer --> StateStore
    APILayer --> Orchestrator
    Orchestrator --> Agent_Perf
    Orchestrator --> Agent_Voice
    Orchestrator --> Agent_Seg
    Orchestrator --> Agent_Journ
    Orchestrator --> Agent_RAG
    Agent_RAG --> KnowledgeLayer
    Orchestrator --> Agent_Opt
    Orchestrator --> Agent_Bud
    Orchestrator --> Agent_Content
    Orchestrator --> Agent_Quality
    Agent_Quality -->|Quality Rejection / Recalibration| Agent_Bud
    Orchestrator --> Agent_Synth
    Agent_Synth --> StateStore
    APILayer -->|POST Webhook on Human Approval| n8n_Webhook
    n8n_Webhook --> n8n_Sheets
    n8n_Webhook --> n8n_Drive
    n8n_Webhook --> n8n_Email
```
