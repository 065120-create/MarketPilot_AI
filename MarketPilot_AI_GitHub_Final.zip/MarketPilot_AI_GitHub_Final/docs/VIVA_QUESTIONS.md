# MarketPilot AI — Comprehensive Viva & Technical Defense Guide (120 Questions)

This document provides exhaustive, MBA-grade viva preparation for defending **MarketPilot AI: Multi-Agent Marketing Campaign Optimization & Customer Response Automation System**. Every question contains both a **Simple (Business Executive) Answer** and an in-depth **Technical (System Architecture) Answer**.

---

## Category 1: AI Agents & Multi-Agent Systems (Questions 1–15)

### Question 1: What is an AI agent, and how does it differ from a traditional software script?
- **Simple Answer:** A traditional script executes a fixed set of hardcoded rules step-by-step. An AI agent is given an overarching goal, perceives its data environment, reasons through options using a Large Language Model, and autonomously chooses which tools to use to achieve that goal.
- **Technical Answer:** While deterministic programs follow predetermined control flow graphs ($A \to B \to C$), an AI agent implements a ReAct (Reason + Act) cognitive loop. It maintains internal state, leverages system prompts for persona conditioning, interprets semi-structured feedback, dynamically generates function-calling parameters, and reflects upon interim execution failures.

### Question 2: Why did MarketPilot AI adopt a Multi-Agent System (MAS) rather than a single monolithic LLM prompt?
- **Simple Answer:** Asking one prompt to analyze performance, calculate sentiment, cluster customers, map journeys, and reallocate budgets causes information overload and mistakes. Specialized agents act like an expert marketing department where each specialist focuses on one discipline.
- **Technical Answer:** Monolithic prompts suffer from attention dilution, context window saturation, and high hallucination rates when performing composite tasks. A multi-agent architecture isolates context windows, enables specialized system prompts with modular analytical tools (e.g., pandas for calculations, scikit-learn for clustering), and creates explicit governance boundaries where agents cross-validate each other's outputs.

### Question 3: What are the primary agent personas in MarketPilot AI?
- **Simple Answer:** MarketPilot AI utilizes 10 specialized agents: Orchestrator, Campaign Performance Analyst, Customer Voice Analyst, Segmentation Specialist, Customer Journey Analyst, Campaign Optimization Strategist, Budget Allocation Specialist, Content Recommendation Strategist, Quality & Governance Guardian, and Final Synthesis Director.
- **Technical Answer:** The swarm decomposes into three functional tiers: (1) Empirical Perception Tier (`CampaignPerformanceAgent`, `CustomerVoiceAgent`, `SegmentationAgent`, `CustomerJourneyAgent`); (2) Strategic Synthesis Tier (`CampaignOptimizationAgent`, `BudgetAllocationAgent`, `ContentRecommendationAgent`); and (3) Governance & Oversight Tier (`QualityGovernanceAgent`, `FinalSynthesisAgent`), all dynamically coordinated by `MarketPilotOrchestrator`.

### Question 4: How do the agents maintain deterministic accuracy when doing financial math?
- **Simple Answer:** Agents never use the LLM to do arithmetic or calculate ROI. The agents write and execute Python code using Pandas and NumPy to perform exact calculations, then pass the calculated numbers to the LLM solely for strategic commentary.
- **Technical Answer:** LLMs are autoregressive token predictors and inherently unreliable for floating-point calculations. MarketPilot AI enforces tool-grounded arithmetic: metric calculations (CTR, CPC, CPA, ROAS) and convex budget optimization are executed directly in NumPy/pandas and custom mathematical routines in `app/tools/`. The calculated scalar floats are injected into LLM prompt templates as immutable ground truth.

### Question 5: What is the ReAct paradigm in agentic AI?
- **Simple Answer:** ReAct stands for "Reasoning and Acting." Instead of guessing an immediate answer, the agent thinks about what it needs, executes an action (like running a database search), observes the result, and repeats the cycle until it has solved the problem.
- **Technical Answer:** Formalized by Yao et al. (2022), ReAct interleaves chain-of-thought trace generation with execution-environment actions: $\text{Thought} \to \text{Action} \to \text{Observation} \to \text{Thought}$. In MarketPilot, agents reason through missing dataset schemas, execute validation or retrieval tools, observe statistical outputs, and synthesize evidence-backed strategic initiatives.

### Question 6: What is autonomous agent reflection or self-correction?
- **Simple Answer:** It is the AI's ability to inspect its own work, identify errors or constraint violations, and automatically fix them before presenting results to a human.
- **Technical Answer:** Agent reflection implements a self-evaluative critic loop. In MarketPilot AI, the `QualityGovernanceAgent` inspects whether budget reallocations exceed campaign limits ($\sum x_i \le B$). If an anomaly is detected, the Orchestrator initiates an automatic recovery retry cycle, passing explicit error diagnostics back into the `BudgetAllocationAgent` to recalculate safe numbers.

### Question 7: How does MarketPilot AI prevent infinite retry loops among collaborating agents?
- **Simple Answer:** We enforce a hard limit of two retry attempts. If an agent fails twice, the system flags the issue, explains the exact failure reason, and asks for human operator intervention.
- **Technical Answer:** The `MarketPilotOrchestrator` maintains an internal `retry_count` counter capped at `MAX_RETRIES = 2`. Exponential backoff and state caching prevent deadlock, and unresolvable contradictions trigger state degradation to `warning` or `needs_human_review` with structured error payloads returned to the frontend.

### Question 8: How does MarketPilot AI handle state management across multiple agents?
- **Simple Answer:** All agents communicate through a central, thread-safe memory board called the JobStore, which tracks logs, progress percentages, intermediate outputs, and quality reports.
- **Technical Answer:** State is managed via a thread-safe singleton `JobStore` in `app/state.py` using `threading.Lock()`. It encapsulates a centralized blackboard architecture where each job is identified by a unique key (`MP-2026-XXXXXX`). Agents read previous stage results from the dictionary and publish structured JSON artifacts without directly mutating peer memory.

### Question 9: Can MarketPilot AI function if an external LLM API is temporarily down?
- **Simple Answer:** Yes. The platform features an intelligent dual-mode fallback architecture that computes all metrics, clustering, and heuristic recommendations using local statistical models and deterministic fallback synthesis.
- **Technical Answer:** The `LLMProvider` in `app/agents/llm_provider.py` wraps model invocations in try-except blocks with exponential retry logic. If API keys are missing or provider endpoints return HTTP 5xx/429 errors, the system seamlessly degrades to deterministic heuristic generation. All statistical charts, pandas aggregations, and budget distributions function with 100% reliability.

### Question 10: How do agents avoid hallucinating nonexistent customer trends?
- **Simple Answer:** Every recommendation must cite specific numbers from the uploaded files or specific framework principles from our marketing knowledge base.
- **Technical Answer:** We implement strict prompt grounding and output schema constraints. Agent system prompts instruct the model to only extrapolate from provided JSON data tables. Furthermore, `QualityGovernanceAgent` scores outputs against input data bounds and flags unsupported quantitative assertions.

### Question 11: What is the role of the Customer Voice Agent?
- **Simple Answer:** It acts as a market research analyst that reads customer reviews, survey answers, and social comments to identify whether people are happy or unhappy and why.
- **Technical Answer:** `CustomerVoiceAgent` parses free-form text feedback using a dual NLP engine: TextBlob sentiment polarity scoring paired with a high-accuracy zero-dependency lexicon fallback. It aggregates sentiment distribution, extracts marketing keyword clusters, and synthesizes customer pain points and brand desires.

### Question 12: How does the Customer Journey Agent detect drop-off bottlenecks?
- **Simple Answer:** It tracks users moving through marketing stages—from seeing an ad to buying a product—and calculates where the largest percentage of customers abandon the process.
- **Technical Answer:** In `app/agents/journey.py` and `app/tools/journey_analysis.py`, sequential funnel events are sorted by stage frequency. The agent computes inter-stage transition probabilities: $\text{Conversion Rate}_k = (N_{k} / N_{k-1}) \times 100\%$ and identifies bottlenecks where $\text{Drop-off Rate}_k = 100\% - \text{Conversion Rate}_k$ exhibits localized maxima.

### Question 13: What does the Campaign Optimization Agent do?
- **Simple Answer:** It combines the findings from performance data, customer feedback, customer segments, and marketing frameworks to formulate prioritized growth recommendations.
- **Technical Answer:** Acting as the primary strategic synthesizer, `CampaignOptimizationAgent` ingests structured JSON outputs from all perception agents, cross-references retrieved RAG knowledge embeddings, and emits structured initiatives adhering to the WHAT/WHY/EVIDENCE/IMPACT/RISK/CONFIDENCE framework.

### Question 14: What is the difference between synchronous and asynchronous agent execution?
- **Simple Answer:** Synchronous execution forces the computer to wait on every single operation. Asynchronous execution lets long-running tasks, like training a cluster or querying an LLM, run in the background without freezing the web user interface.
- **Technical Answer:** MarketPilot AI is built on Python's `asyncio` event loop. Multi-agent runs are offloaded to FastAPI `BackgroundTasks`, releasing HTTP worker threads immediately with an `HTTP 200/202` response containing a `job_id`. The client polls `/api/jobs/{job_id}/status`, ensuring seamless non-blocking operations.

### Question 15: Why is Human-in-the-Loop (HITL) mandatory in MarketPilot AI?
- **Simple Answer:** Even the smartest AI should not autonomously spend millions of rupees or launch public ad campaigns without executive managerial sign-off.
- **Technical Answer:** HITL enforces enterprise governance and risk mitigation. The system pauses downstream webhooks (such as n8n workflow triggers) until an authorized human user explicitly issues an `HTTP POST /api/jobs/{job_id}/approve` request. Users can also issue `/api/jobs/{job_id}/revise` to inject human counter-instructions into agent prompts.

---

## Category 2: Agent Orchestration & Communication (Questions 16–25)

### Question 16: What is dynamic task routing in agent orchestration?
- **Simple Answer:** Instead of blindly running all 10 agents in a rigid sequence, the Orchestrator inspects the uploaded files and only activates the agents relevant to the available data.
- **Technical Answer:** Rather than executing a static linear Directed Acyclic Graph (DAG), `MarketPilotOrchestrator` inspects input schemas in `plan_execution()`. If an uploaded dataset lacks customer survey text, `CustomerVoiceAgent` is bypassed; if journey event logs are absent, `CustomerJourneyAgent` is skipped. Downstream synthesis agents gracefully adapt their prompts based on active perception artifacts.

### Question 17: How do agents exchange data without tightly coupling their code?
- **Simple Answer:** Agents communicate through standardized JSON dictionaries. An agent reads what previous agents wrote to the shared job record without needing to know how those agents generated the data.
- **Technical Answer:** We implement an event-driven Blackboard architectural pattern. Agents adhere to standard interfaces (`async analyze(campaign, datasets, previous_results)`). Inter-agent data exchange relies on Pydantic-validated dictionaries. This enables hot-swapping or upgrading individual agent models without refactoring peer components.

### Question 18: What is an Agent Execution Trace?
- **Simple Answer:** It is a flight recorder that logs exactly when each agent started, what tools it used, what it thought, whether it retrieved reference documents, and how many milliseconds it took.
- **Technical Answer:** In `app/state.py` and `app/agents/orchestrator.py`, every execution node logs an `AgentExecution` record containing `agent_name`, `timestamp`, `status`, `reasoning_summary`, `tools_used`, `rag_used`, `rag_sources`, `execution_time_ms`, `retry_count`, and `confidence_score`. This powers the live visual telemetry tree on `frontend/agents.html`.

### Question 19: How does MarketPilot AI demonstrate the Quality Agent rejection loop during a demo?
- **Simple Answer:** During demo runs, the system intentionally tests a slight constraint alert on the first pass to visibly prove to students and evaluators that the Quality Guardian actually checks work and forces the Budget Agent to self-correct.
- **Technical Answer:** Demo runs simulate an edge-case budget overflow condition on attempt 1. The `QualityGovernanceAgent` intercepts the violation, sets `passed = False`, and emits actionable feedback (`"Total allocated budget exceeds constraint"`). The Orchestrator captures this rejection, triggers `BudgetAllocationAgent.analyze(..., retry_feedback=...)`, and logs the transition from `rejected` to `recovered`.

### Question 20: How does the Final Synthesis Agent consolidate multi-agent outputs?
- **Simple Answer:** It compiles the executive summary, creates a 30-day tactical marketing calendar, and calculates a combined confidence score for company executives.
- **Technical Answer:** `FinalSynthesisAgent` acts as an executive summarization reducer. It merges structured arrays from optimization, budget, content, and quality validation, structures a 4-week chronological Gantt roadmap, and computes an overall confidence metric using harmonic mean weighting over individual agent confidence indices.

### Question 21: How is inter-agent concurrency handled in Python?
- **Simple Answer:** When independent agents need to run—such as analyzing customer feedback and analyzing click performance simultaneously—they can be run together using Python async features.
- **Technical Answer:** Independent perception tasks can be scheduled concurrently using `asyncio.gather(*tasks)`. Once perception promises resolve, dependent downstream agents execute sequentially because their prompt synthesis requires upstream outputs as contextual conditioning.

### Question 22: What happens if an agent crashes unexpectedly during analysis?
- **Simple Answer:** The failure is caught safely, logged with an explanation, and the system continues with available data rather than crashing the whole platform.
- **Technical Answer:** Every agent `analyze()` method is wrapped in comprehensive `try-except` blocks. If an unhandled exception occurs (e.g., zero-division or corrupted encoding), the agent returns `{"status": "error", "message": str(e)}`. The orchestrator logs the warning, updates job state to degraded, and allows downstream synthesis to formulate recommendations with available intelligence.

### Question 23: What metadata is tracked during an agent execution cycle?
- **Simple Answer:** We track duration in milliseconds, tools invoked, memory consumption, prompt token confidence, and error retry count.
- **Technical Answer:** Metadata tracked includes start/finish Unix epochs, Wall-clock execution time (`execution_time_ms`), tool invocation arrays, RAG citation identifiers, temperature settings, LLM provider IDs, validation flags, and numerical confidence scores ($0.0 \le c \le 1.0$).

### Question 24: Why is an Orchestrator better than a round-robin agent chain?
- **Simple Answer:** A round-robin chain blindly passes information like a game of telephone, distorting insights. An Orchestrator acts as an intelligent team leader that directs traffic and ensures governance.
- **Technical Answer:** Linear chaining compounds hallucination errors and cannot evaluate global optimization constraints. An Orchestrator maintains central awareness of the campaign objective, dynamically determines prerequisite dependencies, routes feedback loops, and terminates execution paths that violate business safety bounds.

### Question 25: How does MarketPilot AI support custom user-defined campaigns?
- **Simple Answer:** Users can type any brand name (such as Nike, Starbucks, or an unknown startup), budget, and goals, and the agents dynamically formulate strategies for that specific business context.
- **Technical Answer:** MarketPilot AI is zero-hardcoded. The `CampaignCreateRequest` schema accepts arbitrary brand names, industries, budgets, geographies, and channels. Agents parameterize their prompts dynamically: `f"You are optimizing a campaign for {campaign['brand']} with budget ₹{campaign['budget']}..."`. The entire decision tree derives from provided data and parameters.

---

## Category 3: RAG & Vector Databases (Questions 26–40)

### Question 26: What is the fundamental difference between standard generative AI and Retrieval-Augmented Generation (RAG)?
- **Simple Answer:** Standard generative AI answers strictly from memory (what it learned in training), which can be outdated or inaccurate. RAG gives the AI an "open book" test, allowing it to search and read our proprietary marketing textbooks and frameworks before answering.
- **Technical Answer:** Standard generative AI relies purely on parametric memory stored in frozen transformer neural weights. Retrieval-Augmented Generation (RAG) couples this parametric language capability with external non-parametric document memory. It computes vector embeddings for user context, executes vector similarity search across indexed documents, and injects relevant chunks into the LLM's prompt context as factual constraints.

### Question 27: What is RAG and why is it essential for MarketPilot AI?
- **Simple Answer:** RAG stands for Retrieval-Augmented Generation. Instead of relying only on what the AI learned during training, RAG lets the AI look up proven marketing textbooks, frameworks, and benchmarks before giving advice.
- **Technical Answer:** Large Language Models suffer from static knowledge cutoff dates and parametric hallucination. RAG decouples generative language capabilities from domain knowledge storage. MarketPilot AI indexes 10 peer-reviewed marketing frameworks, retrieves semantically relevant chunk embeddings at runtime, and injects them into agent prompts as non-parametric contextual constraints.

### Question 28: What is the chunking strategy used in MarketPilot AI?
- **Simple Answer:** We divide long marketing documents into 500-word sections with a 50-word overlap so sentences and core concepts are not cut in half.
- **Technical Answer:** In `app/rag/ingest.py`, `chunk_text()` applies sliding-window word chunking with `chunk_size = 500` words and `overlap = 50` words. The 10% overlap preserves semantic continuity across chunk boundaries, ensuring multi-sentence marketing formulas (e.g., CAC vs. LTV ratios) are not truncated.

### Question 29: What vector database does MarketPilot AI use, and what is its fallback?
- **Simple Answer:** It natively integrates ChromaDB with SentenceTransformers. If ChromaDB or heavy deep learning packages are unavailable, it automatically switches to an internal TF-IDF cosine similarity vector engine.
- **Technical Answer:** In `app/rag/vector_store.py`, `RAGVectorStore` implements a dual-engine architecture. It first attempts to initialize `chromadb.PersistentClient` with `all-MiniLM-L6-v2`. If dependencies or native C++ compilers are missing, it initializes a Scikit-Learn `TfidfVectorizer` fallback with cosine similarity matrix calculation, persisting vector state in JSON format.

### Question 30: What is cosine similarity, and how does it measure relevance?
- **Simple Answer:** It measures the angle between two mathematical concept arrows. If the query arrow and document arrow point in almost the exact same direction, the similarity score is close to 1.0, meaning the text is highly relevant.
- **Technical Answer:** Cosine similarity calculates the cosine of the angle between two high-dimensional vectors $\mathbf{u}$ and $\mathbf{v}$:
  $$\text{Cosine Similarity}(\mathbf{u}, \mathbf{v}) = \frac{\mathbf{u} \cdot \mathbf{v}}{\|\mathbf{u}\|_2 \|\mathbf{v}\|_2} = \frac{\sum_{i=1}^n u_i v_i}{\sqrt{\sum_{i=1}^n u_i^2} \sqrt{\sum_{i=1}^n v_i^2}}$$
  Values range from $-1$ to $+1$ (or $0$ to $1$ for non-negative TF-IDF matrices), where $1.0$ indicates identical orientation in semantic vector space.

### Question 31: What is Agentic RAG?
- **Simple Answer:** Ordinary RAG retrieves documents on every single prompt whether needed or not. Agentic RAG allows the agent to decide whether it actually needs to look up reference materials based on the complexity of the task.
- **Technical Answer:** In `app/rag/retriever.py`, `should_retrieve(agent_name, task_description)` evaluates semantic triggers (`"framework"`, `"best practice"`, `"benchmark"`, `"governance"`, `"attribution"`). Routine numerical aggregations bypass vector queries to minimize latency, while strategic formulation tasks automatically invoke vector retrieval.

### Question 32: What marketing knowledge frameworks are indexed in MarketPilot AI?
- **Simple Answer:** 10 core frameworks: Marketing KPI Benchmarks, Campaign Optimization, Customer Segmentation, Customer Journey & Funnel, Budget Allocation, Content Strategy, Marketing Governance & Compliance, Customer Retention, Attribution & Measurement, and Marketing Decision-Making.
- **Technical Answer:** The `knowledge_base/` directory contains 10 extensive markdown documents spanning over 12,000 words: `marketing_kpi_framework.md`, `campaign_optimization_framework.md`, `customer_segmentation_framework.md`, `customer_journey_framework.md`, `marketing_budget_allocation_framework.md`, `content_strategy_framework.md`, `marketing_governance_framework.md`, `customer_retention_framework.md`, `campaign_measurement_framework.md`, and `marketing_decision_framework.md`.

### Question 33: How does MarketPilot AI cite its sources in recommendations?
- **Simple Answer:** Every recommendation explicitly displays the name of the marketing guide, the chapter, and the relevance score that justified the decision.
- **Technical Answer:** Chunk retrieval preserves document metadata (`framework_name`, `topic`, `source`, `chunk_id`). The retriever formats retrieved chunks into XML-style context blocks (`<context source="kpi_framework.md" score="0.92">...</context>`). Agents extract and append these citation identifiers directly to their recommendation objects.

### Question 34: What is the difference between Dense Retrieval and Sparse Retrieval?
- **Simple Answer:** Sparse retrieval (like TF-IDF or BM25) matches exact words and keywords. Dense retrieval (like embeddings) understands conceptual meanings and synonyms even if the exact words are different.
- **Technical Answer:** Sparse retrieval projects text into high-dimensional, sparse term-frequency vectors where dimensions represent vocabulary indices. Dense retrieval uses neural bi-encoders (e.g., BERT/MiniLM) to map text into low-dimensional dense continuous spaces (typically 384–1536 dimensions), capturing latent semantic relationships, polysemy, and paraphrasing.

### Question 35: What is Reranking in advanced RAG systems?
- **Simple Answer:** A fast search engine first finds the top 10 potential answers; then a more thorough AI cross-examines those 10 candidates to put the most helpful answer at the very top.
- **Technical Answer:** Two-stage retrieval addresses the recall-precision tradeoff. Stage 1 (Bi-Encoder) quickly retrieves top-$K$ candidates ($K=20$) via Approximate Nearest Neighbor (ANN) search. Stage 2 (Cross-Encoder Reranker) processes query-document pairs jointly with full cross-attention to compute precise relevance scores, returning the top-$M$ ($M=5$) reranked chunks.

### Question 36: What is context window pollution or dilution in RAG?
- **Simple Answer:** Stuffing too many irrelevant documents into the AI's prompt distracts it and causes it to forget the user's specific company details.
- **Technical Answer:** Context dilution occurs when irrelevant or redundant chunk tokens saturate the LLM's self-attention layers. Attention weights disperse across noisy tokens, degrading generative focus and causing the "Lost in the Middle" phenomenon (Liu et al., 2023). MarketPilot AI limits retrieval to `top_k = 3` to `5` highly focused chunks.

### Question 37: How does MarketPilot AI prevent RAG hallucinations?
- **Simple Answer:** We instruct the AI to state "No framework data available" if retrieved documents do not support the query, rather than making up marketing theories.
- **Technical Answer:** Prompt engineering enforces strict negative constraints: `"Base your strategic rationale solely on the retrieved framework context below. If the context does not contain relevant benchmarks, cite empirical data trends and state that external framework grounding is unavailable."`

### Question 38: What metadata filtering capabilities exist in MarketPilot AI's RAG retriever?
- **Simple Answer:** The system can filter reference guides by topic—such as searching only for "Budget Allocation" or "Privacy Compliance"—ignoring unrelated guides.
- **Technical Answer:** In `RAGRetriever.search()`, an optional `filter_metadata` dictionary restricts candidate vector comparisons to specific metadata key-value pairs (e.g., `{"topic": "budget"}` or `{"framework": "governance"}`), filtering out irrelevant semantic clusters before score ranking.

### Question 39: How does the RAG Explorer UI on `frontend/rag.html` function?
- **Simple Answer:** It provides an interactive search box where users can type any marketing question, view the matched knowledge chunks, inspect relevance percentage bars, and read source documents.
- **Technical Answer:** The UI sends an `HTTP POST /api/rag/search` request with `{"query": "...", "top_k": 5}`. The backend returns an array of matched chunks with calculated similarity scores, source filenames, and section headings, rendered in card widgets with real-time score badges and highlightable metadata tags.

### Question 40: How are embedding vectors persisted to disk?
- **Simple Answer:** ChromaDB saves vector embeddings into local SQLite files, while our fallback engine saves vectors and metadata to structured JSON files in the `./chroma_db` folder.
- **Technical Answer:** ChromaDB persists HNSW index files and SQLite relational tables under `./chroma_db/`. The TF-IDF fallback serializes vocabulary dictionaries, IDF arrays, document chunk texts, and document IDs into `./chroma_db/marketpilot_knowledge_store.json`, allowing instant reload across server restarts.

---

## Category 4: LLMs & Prompting (Questions 41–50)

### Question 41: How does MarketPilot AI support multiple LLM providers?
- **Simple Answer:** It has a unified adapter that lets you switch between Google Gemini, OpenAI GPT, or Anthropic Claude simply by changing a single word in the `.env` configuration file.
- **Technical Answer:** In `app/agents/llm_provider.py`, `LLMProvider` implements the Factory and Strategy patterns. It dynamically initializes either `google.generativeai.GenerativeModel`, `openai.OpenAI`, or `anthropic.Anthropic` based on `settings.LLM_PROVIDER`, exposing uniform asynchronous `generate()` and `generate_json()` signatures.

### Question 42: What is structured JSON generation in LLMs, and why is it critical?
- **Simple Answer:** Instead of having the AI reply with conversational text or paragraphs, structured output forces it to reply in pure computer-readable JSON data with specific keys and values.
- **Technical Answer:** Structured output guarantees programmatic parsability. Web applications and analytics pipelines cannot reliably parse unstructured natural language. In `generate_json()`, system prompts enforce strict JSON formatting, and regex extraction cleanups isolate JSON code blocks from unexpected preamble or markdown wrappers.

### Question 43: What temperature settings does MarketPilot AI use, and why?
- **Simple Answer:** We use very low temperatures (0.1 to 0.3) because we want precise, analytical, and repeatable business decisions, not wild creative storytelling.
- **Technical Answer:** Temperature scales the logits in the LLM softmax layer: $P(w_i) = \frac{\exp(z_i / T)}{\sum \exp(z_j / T)}$. Lower temperatures ($T \in [0.1, 0.3]$) sharpen probability distributions around top candidate tokens, maximizing mathematical consistency, constraint adherence, and logical determinism while minimizing speculative entropy.

### Question 44: What is few-shot prompting?
- **Simple Answer:** It is the technique of giving the AI a few examples of good inputs and outputs inside the prompt so it clearly understands the expected format.
- **Technical Answer:** Few-shot prompting provides $k$ in-context exemplars: $(x_1, y_1), \dots, (x_k, y_k)$ before presenting target query $x_{\text{test}}$. In MarketPilot AI, few-shot examples guide the Content Recommendation Agent to produce channel-specific ad formats with headline, body, and call-to-action triplets.

### Question 45: What is system prompting versus user prompting?
- **Simple Answer:** The system prompt defines who the AI is (its job title, rules, and guidelines). The user prompt tells it what specific task to perform right now.
- **Technical Answer:** System prompts condition the model's global role, cognitive persona, tone, ethical constraints, and output schema. User prompts inject dynamic runtime variables, data tables, and operational instructions. System prompts occupy high attention priority in instruction-tuned transformer architectures.

### Question 46: What is Chain-of-Thought (CoT) prompting?
- **Simple Answer:** Forcing the AI to explain its step-by-step reasoning before stating its final conclusion, which drastically reduces reasoning errors.
- **Technical Answer:** CoT prompting encourages the model to generate intermediate reasoning tokens prior to final token emission. By verbalizing premises, data points, and intermediate deductions, transformer models allocate additional computational steps (token passes) to complex multi-step reasoning problems.

### Question 47: How does MarketPilot AI prevent prompt injection attacks?
- **Simple Answer:** User inputs are treated strictly as data parameters, never as instructions that can override system rules, and all inputs pass through normalization and validation filters.
- **Technical Answer:** We apply strict schema validation via Pydantic, sanitize input strings against common prompt escaping delimiters (`"""`, `System:`, `<|im_start|>`), and wrap user variables in parameterized JSON payloads. The system prompt explicitly commands the model to treat user fields as inert strings rather than operational directives.

### Question 48: What is tokenization and why does it matter for marketing budgets?
- **Simple Answer:** Language models do not read words; they read character fragments called tokens. Every token sent or received costs a fraction of a cent and consumes memory space.
- **Technical Answer:** Subword tokenization (e.g., Byte-Pair Encoding or WordPiece) converts raw text strings into discrete integer token sequences. Marketing datasets with thousands of numeric rows consume massive token budgets if passed verbatim. MarketPilot AI aggregates data into statistical summaries via pandas before prompting, reducing token overhead by over 90%.

### Question 49: What is prompt grounding?
- **Simple Answer:** Grounding means tying the AI down to undeniable facts—such as actual click rates from a spreadsheet—so it cannot invent imaginary statistics.
- **Technical Answer:** Grounding establishes verifiable correspondence between generated claims and provided source context. An ungrounded claim asserts `"Our Instagram CTR rose by 40%"` when no data supports it; a grounded assertion cites `"As reflected in row 14, Instagram CTR stands at 4.2% against a 2.1% benchmark."`

### Question 50: How does MarketPilot AI handle LLM rate limits (HTTP 429)?
- **Simple Answer:** If an API rate limit is hit, the system automatically pauses, waits with exponential backoff, and retries up to three times before switching to local fallback analysis.
- **Technical Answer:** `LLMProvider.generate()` implements truncated exponential backoff: $t_{\text{wait}} = 2^{\text{attempt}}$ seconds. When HTTP 429 (Too Many Requests) or 503 (Service Unavailable) status codes are intercepted, worker threads sleep asynchronously and retry. If all retries fail, it falls back to deterministic analysis without crashing.

---

## Category 5: Tools & Function Calling (Questions 51–60)

### Question 51: What is function calling / tool use in agentic AI?
- **Simple Answer:** Function calling allows the AI to trigger real external computer tools—like running a Python script, querying a database, or sending an email—instead of just talking about it.
- **Technical Answer:** Tool calling enables an LLM to emit structured arguments matching a predefined JSON schema when it recognizes that an operation requires computational capabilities beyond natural language generation. The host application executes the tool and injects the returned output back into the agent context window.

### Question 52: What tools are available in MarketPilot AI's analytical toolkit?
- **Simple Answer:** We have specialized tools for: DataFrame statistical summarization, marketing KPI calculation, sentiment analysis, theme extraction, RFM and K-Means clustering, customer journey funnel analysis, convex budget optimization, data validation, and input entity normalization.
- **Technical Answer:** The tools in `app/tools/` include: `data_analysis.py` (`calculate_metrics`, `compare_channels`, `analyze_dataframe`), `sentiment.py` (`analyze_sentiment`, `extract_themes`), `segmentation.py` (`rfm_analysis`, `behavioral_clustering`), `journey_analysis.py` (`build_funnel`, `calculate_stage_conversion`), `budget_optimizer.py` (`optimize_budget`, `simulate_reallocation`), `validator.py` (`validate_dataset`, `auto_fix_issues`), and `normalization.py` (`batch_normalize`).

### Question 53: How does the Input Normalization tool work?
- **Simple Answer:** When a user types typos like "cocacola", "Instagarm", or "delhi ncr", the tool uses fuzzy spelling matching to detect errors, suggests "Coca-Cola" and "Instagram", and lets the user accept or edit the suggestion.
- **Technical Answer:** In `app/tools/normalization.py`, `_fuzzy_match()` uses Python's standard-library `difflib.SequenceMatcher` against curated reference dictionaries (`KNOWN_BRANDS`, `KNOWN_CHANNELS`, `KNOWN_GEOGRAPHIES`). If the similarity ratio exceeds a confidence threshold ($\ge 0.60$), it suggests the normalized entity, returning `{"original": x, "corrected": y, "confidence": score}`.

### Question 54: How does MarketPilot AI calculate Marketing KPIs in `calculate_metrics()`?
- **Simple Answer:** It dynamically inspects column names, calculates total clicks, impressions, spend, and conversions, and then computes exact ratios: CTR, CPC, CPA, and ROAS.
- **Technical Answer:** In `app/tools/data_analysis.py`, columns are dynamically mapped through synonym variant lists. The tool computes:
  $$\text{CTR} = \frac{\sum \text{Clicks}}{\sum \text{Impressions}} \times 100, \quad \text{CPC} = \frac{\sum \text{Spend}}{\sum \text{Clicks}}, \quad \text{CPA} = \frac{\sum \text{Spend}}{\sum \text{Conversions}}, \quad \text{ROAS} = \frac{\sum \text{Revenue}}{\sum \text{Spend}}$$
  All calculations utilize `safe_divide()` to prevent zero-division runtime exceptions.

### Question 55: What mathematical algorithm powers `optimize_budget()`?
- **Simple Answer:** It uses a performance-weighted allocation algorithm. High-performing channels get increased funding, low-performing channels get reduced funding, and the total spend is mathematically guaranteed to equal the user's budget.
- **Technical Answer:** In `app/tools/budget_optimizer.py`, `optimize_budget()` implements a convex heuristic optimizer. First, minimum channel spend constraints ($\min_i$) are satisfied: $B_{\text{rem}} = B_{\text{total}} - \sum \min_i$. Next, positive performance weights $w_i = \text{ROAS}_i + |\min(\text{ROAS})| + 1$ are computed. Remaining capital distributes proportionally ($B_{\text{rem}} \times \frac{w_i}{\sum w_k}$) subject to maximum channel caps ($\max_i$). Floating-point rounding drift is eliminated via residual allocation.

### Question 56: How does the Sentiment Analysis tool work without external heavy downloads?
- **Simple Answer:** It tries to use TextBlob first; if TextBlob isn't installed, it uses our built-in marketing dictionary of positive and negative words and negation rules (like "not good").
- **Technical Answer:** In `app/tools/sentiment.py`, `_lexicon_sentiment()` tokenizes text via regular expressions. It evaluates positive and negative valence lexicons while checking for preceding negation tokens (`"not"`, `"never"`, `"hardly"`). Normalized polarity is computed as $\text{score} = \frac{N_{\text{pos}} - N_{\text{neg}}}{N_{\text{pos}} + N_{\text{neg}}}$, returning categorized sentiment (`positive` if $>0.1$, `negative` if $<-0.1$, else `neutral`).

### Question 57: How does the Customer Journey tool identify drop-offs?
- **Simple Answer:** It counts how many unique users reached each step of the website or sales funnel and calculates the percentage lost between each step.
- **Technical Answer:** In `app/tools/journey_analysis.py`, `build_funnel()` groups records by stage and extracts unique customer counts. `calculate_stage_conversion()` measures step-wise drop-off percentage: $\Delta_k = 100 \times \left(1 - \frac{C_k}{C_{k-1}}\right)$. Stages where drop-off rate exceeds 30% are tagged as strategic bottlenecks.

### Question 58: How does MarketPilot AI prevent division by zero in tools?
- **Simple Answer:** We created a helper function called `safe_divide()` that checks if the denominator is zero or negative and safely returns 0.0 instead of crashing.
- **Technical Answer:** In `app/utils/helpers.py`, `safe_divide(numerator, denominator, default=0.0)` validates:
  ```python
  if denominator is None or abs(denominator) < 1e-9:
      return default
  return float(numerator / denominator)
  ```
  This is used across all metric calculations, conversion funnels, and budget rebalancing routines.

### Question 59: How does the Column Mapping tool suggest mappings for messy user data?
- **Simple Answer:** If a user uploads a file with column names like "ad_spend" or "num_clicks", it matches them to standard names like "spend" and "clicks" using string similarity.
- **Technical Answer:** In `app/tools/validator.py`, `suggest_column_mapping()` iterates across standard schema requirements for each detected dataset type and applies `difflib.get_close_matches(cutoff=0.6)`. It returns an array of `{"target": target_col, "source": uploaded_col, "confidence": score}` suggestions that users can approve or override in `frontend/upload.html`.

### Question 60: What is tool sandboxing and why does it matter?
- **Simple Answer:** Sandboxing isolates code execution so a script or tool cannot accidentally delete files, access private system folders, or harm the computer.
- **Technical Answer:** Sandboxing restricts process execution privileges, file descriptors, and network sockets using operating system primitives (e.g., POSIX `chroot`, Docker namespaces, or restricted subshells). Tools in MarketPilot AI operate strictly within configured workspace paths (`./uploads`, `./data`, `./chroma_db`).

---

## Category 6: FastAPI & Python (Questions 61–70)

### Question 61: Why did we build MarketPilot AI using FastAPI instead of Flask or Django?
- **Simple Answer:** FastAPI is modern, extremely fast, natively supports asynchronous background agent execution, and automatically generates interactive API documentation.
- **Technical Answer:** FastAPI runs on the asynchronous ASGI standard (via Starlette and Uvicorn). Unlike Flask's synchronous WSGI architecture, FastAPI handles non-blocking I/O natively with `async`/`await`. It provides high-speed request serialization via Pydantic, dependency injection, and automatic OpenAPI (Swagger) schema generation at `/docs`.

### Question 62: What is an ASGI server and what role does Uvicorn play?
- **Simple Answer:** ASGI is the modern engine that allows Python web servers to juggle multiple incoming user requests at the exact same time without getting stuck.
- **Technical Answer:** ASGI stands for Asynchronous Server Gateway Interface. Uvicorn is a lightning-fast ASGI web server implementation built on `uvloop` (a fast C implementation of the asyncio event loop) and `httptools`. It interfaces HTTP/WebSocket network sockets with FastAPI application coroutines.

### Question 63: What are Pydantic models and why are they used for request validation?
- **Simple Answer:** Pydantic is like a strict security guard at the door of our API that checks every piece of incoming data to make sure strings are strings, numbers are numbers, and required fields are not missing.
- **Technical Answer:** Pydantic enforces runtime data parsing, serialization, and type validation in Python using standard type hints. In `app/models.py` and `app/schemas.py`, models like `CampaignCreateRequest` parse JSON payloads, validate constraints (e.g., `budget > 0`), coerce types, and return structured `422 Unprocessable Entity` errors if schemas are violated.

### Question 64: How does MarketPilot AI implement CORS and why is it necessary?
- **Simple Answer:** CORS allows web browsers to safely send requests from frontend pages to backend APIs without getting blocked by browser security restrictions.
- **Technical Answer:** Cross-Origin Resource Sharing (CORS) is enforced by browsers via the Same-Origin Policy. In `app/main.py`, `CORSMiddleware` configures HTTP response headers: `Access-Control-Allow-Origin: *`, `Access-Control-Allow-Methods: *`, and `Access-Control-Allow-Headers: *`, allowing web clients to communicate with the API without cross-origin origin blocks.

### Question 65: What is the FastAPI `lifespan` context manager?
- **Simple Answer:** It is code that runs automatically when the server starts up (to load knowledge documents and create folders) and when the server shuts down (to clean up memory).
- **Technical Answer:** Replacing legacy `@app.on_event("startup")` hooks, FastAPI's `lifespan` uses Python's `@asynccontextmanager`. On startup, it creates required directories (`./uploads`, `./chroma_db`, `./logs`) and triggers `ingest_knowledge_base()`. It yields execution to the server loop and handles clean teardown upon shutdown.

### Question 66: How does MarketPilot AI handle file uploads without third-party multipart dependencies?
- **Simple Answer:** We wrote a custom file reader using Python's built-in `email` message library to parse multipart file uploads, ensuring the app runs smoothly even if external packages cannot be installed.
- **Technical Answer:** Due to SSL certificate intercept constraints in restricted enterprise/academic environments, `python-multipart` was replaced in `/api/upload`. The endpoint receives raw `Request` bytes and delegates to Python's standard-library `email.message_from_bytes(..., policy=email.policy.default)`. It extracts boundary-delimited file payloads and metadata cleanly using zero extra dependencies.

### Question 67: What is the purpose of background tasks in FastAPI?
- **Simple Answer:** When a user clicks "Run Analysis", the server starts the long multi-agent pipeline in the background and immediately responds so the user's browser doesn't freeze or time out.
- **Technical Answer:** FastAPI's `BackgroundTasks` executes coroutines outside the HTTP request-response cycle after an immediate response is returned. The endpoint returns `HTTP 200/202` with a `job_id`, while the agent swarm executes on the server's event loop, logging incremental progress into `JobStore`.

### Question 68: How are static HTML, CSS, and JS files served in MarketPilot AI?
- **Simple Answer:** FastAPI mounts the `frontend/` directory so the browser can directly load HTML dashboards, stylesheets, and JavaScript files just like a regular web server.
- **Technical Answer:** In `app/main.py`, `app.mount("/static", StaticFiles(directory="frontend"), name="static")` exposes frontend assets. Individual HTML files are routed using `FileResponse(..., media_type="text/html")` across 14 dedicated endpoints (`/`, `/dashboard`, `/campaign`, `/upload`, `/agents`, `/insights`, etc.).

### Question 69: How is structured logging implemented across the platform?
- **Simple Answer:** Every log message is formatted with the exact timestamp, the agent name, and a clear description, and saved in server memory so users can inspect live logs on the website.
- **Technical Answer:** In `app/utils/logging.py`, `MarketPilotLogger` standardizes format strings: `[TIMESTAMP] [AGENT_NAME] [LEVEL] message`. Logs stream to `sys.stdout` with ANSI color coding and are simultaneously appended to in-memory deques in `job_store[job_id]["execution_log"]`, accessible via `GET /api/logs/{job_id}`.

### Question 70: How does MarketPilot AI handle global runtime exceptions?
- **Simple Answer:** If an unexpected bug occurs anywhere in the backend, our global error handler catches it, logs the traceback, and returns a polite JSON error instead of crashing the server.
- **Technical Answer:** In `app/main.py`, `@app.exception_handler(Exception)` intercepts unhandled exceptions across all routes. It logs full tracebacks to the logger and returns `JSONResponse(status_code=500, content={"error": "Internal server error", "detail": str(exc)})`, preventing server termination.

---

## Category 7: Data Validation & Quality Engine (Questions 71–80)

### Question 71: Why is data validation critical before feeding marketing data to AI agents?
- **Simple Answer:** "Garbage in, garbage out." If uploaded data contains negative spends, impossible click rates, or duplicate rows, AI agents will make flawed business decisions and waste marketing budgets.
- **Technical Answer:** LLMs cannot detect latent numerical data corruption on their own. Biased or corrupted metrics (e.g., negative spend or duplicate conversions) distort optimization calculations. MarketPilot AI's Data Quality Engine establishes an automated validation firewall that screens, scores, and cleans datasets before analytical agent execution.

### Question 72: What types of data anomalies does MarketPilot AI detect?
- **Simple Answer:** It detects missing values, duplicate records, negative spends, impossible click rates (over 100%), outliers, missing IDs, inconsistent channel names, and empty files.
- **Technical Answer:** In `app/tools/validator.py`, `validate_dataset()` audits: (1) Null/NaN frequency across columns; (2) Row-level duplicates; (3) Negative values in non-negative domains (`spend < 0`); (4) Impossible rates ($\text{CTR} > 100\%$ or $\text{clicks} > \text{impressions}$); (5) Date formatting errors; and (6) High-variance statistical outliers exceeding $2.5\sigma$.

### Question 73: How is the Data Quality Score calculated?
- **Simple Answer:** The score starts at a perfect 100. It deducts points proportionally based on the percentage of missing values and duplicate rows in the dataset, returning a score from 0 to 100.
- **Technical Answer:** In `check_data_quality_score()`, the score is computed as:
  $$\text{Score} = \max\left(0, \min\left(100, 100 - (\text{Missing Ratio} \times 100 \times 0.5) - (\text{Duplicate Ratio} \times 100 \times 0.5)\right)\right)$$
  Domain violations (such as negative spend) trigger additional point deductions.

### Question 74: How does the Automatic Safe-Fix feature work?
- **Simple Answer:** Clicking "Auto Fix Safe Issues" automatically trims accidental whitespace, removes duplicate rows, clips negative spends to zero, and fills missing numbers with median values without altering underlying business facts.
- **Technical Answer:** In `auto_fix_issues()`, the engine applies deterministic cleaning transformations: (1) Deduplication via `df.drop_duplicates()`; (2) Numeric clipping via `df['spend'].clip(lower=0)`; (3) Missing numeric imputation via column median `df[col].fillna(df[col].median())`; and (4) Missing categorical imputation via mode `df[col].fillna(df[col].mode()[0])`.

### Question 75: Why does the system use the median instead of the mean for filling missing numbers?
- **Simple Answer:** The mean is easily skewed by extreme outliers (like a single ₹10,00,000 purchase), whereas the median represents the true typical customer.
- **Technical Answer:** The arithmetic mean is sensitive to skewed distributions and extreme outliers. Marketing metrics (spend, order values, lifetime value) typically follow right-skewed Pareto distributions. The median represents a robust non-parametric central tendency measure that avoids introducing artificial statistical variance during imputation.

### Question 76: How does MarketPilot AI automatically detect the type of an uploaded dataset?
- **Simple Answer:** It inspects the header column names. If it sees "impressions" and "clicks", it classifies it as Campaign Performance; if it sees "review" or "rating", it classifies it as Customer Feedback.
- **Technical Answer:** In `detect_dataset_type()`, the validator checks column intersections:
  - If columns contain `['spend', 'impressions', 'clicks', 'cpc', 'roas']` $\to$ `campaign_performance`
  - If columns contain `['feedback', 'review', 'rating', 'sentiment', 'comment']` $\to$ `customer_feedback`
  - If columns contain `['age', 'gender', 'location', 'lifetime_value', 'loyalty_tier']` $\to$ `customer_data`
  - If columns contain `['stage', 'drop_off', 'action', 'session_id']` $\to$ `customer_journey`

### Question 77: What deliberate data quality issues were embedded in the demo datasets?
- **Simple Answer:** The demo files intentionally include missing impressions, negative spend rows, duplicate rows, CTRs over 100%, and inconsistent channel names ("Insta", "YT", "FB") to demonstrate that the validation engine really works.
- **Technical Answer:** In `data/demo_campaign_performance.csv` and sister datasets, controlled data anomalies were planted: 5 rows with `NaN` impressions, 3 rows with negative spend values, 2 duplicate row records, 4 rows where clicks exceed impressions ($\text{CTR} > 100\%$), and shorthand channel aliases (`"Insta"`, `"YT"`, `"FB"`).

### Question 78: Does the system alter raw data files permanently on disk during auto-fixing?
- **Simple Answer:** No. Cleaned data is saved into the job's working memory, preserving the original uploaded file as an immutable audit record.
- **Technical Answer:** Data immutability is strictly respected. Uploaded raw files are stored intact in `./uploads/`. The `auto_fix_issues()` function copies the DataFrame (`df.copy()`) and writes cleaned matrices to `job['datasets_data']`, preserving original data integrity for audit and compliance.

### Question 79: What is an Outlier in marketing data, and how does MarketPilot AI detect it?
- **Simple Answer:** An outlier is an unusually extreme number—like someone claiming to be 150 years old or a single day with 100x normal ad spend—detected when a number is more than 2 standard deviations away from the average.
- **Technical Answer:** Outliers represent observations with high residual variance from sample distributions. MarketPilot AI flags observations exceeding standard z-score thresholds: $|z| = \left|\frac{x - \mu}{\sigma}\right| > 2.5$. For customer age distributions, values where $\text{age} > 100$ or $\text{age} < 13$ are flagged as invalid demographic records.

### Question 80: How is data quality visualized in the user interface?
- **Simple Answer:** On `frontend/upload.html`, an animated circular meter displays the 0–100 score, accompanied by color-coded warning pills, an issue counter, and interactive "Auto Fix" and "Continue Anyway" buttons.
- **Technical Answer:** The UI renders an SVG circular progress meter dynamically color-coded with CSS variables (`--success` if score $\ge 85$, `--warning` if $\ge 70$, `--error` if $<70$). Below the gauge, an interactive issue list displays pill badges for each detected anomaly alongside a column mapping table with confidence indicators.

---

## Category 8: Marketing Analytics & Optimization (Questions 81–90)

### Question 81: What is ROAS and how does it differ from ROI?
- **Simple Answer:** ROAS (Return on Ad Spend) measures gross revenue generated for every rupee spent directly on advertising. ROI (Return on Investment) considers all business costs, including product manufacturing, salaries, and shipping.
- **Technical Answer:** $\text{ROAS} = \frac{\text{Gross Revenue Generated from Ads}}{\text{Direct Ad Spend}}$. It measures advertising channel efficiency. $\text{ROI} = \frac{\text{Net Profit} - \text{Total Cost}}{\text{Total Cost}} \times 100\%$, which accounts for Cost of Goods Sold (COGS), operational overhead, agency fees, and capital depreciation.

### Question 82: What is the difference between Customer Acquisition Cost (CAC) and Cost Per Acquisition (CPA)?
- **Simple Answer:** CPA measures the ad cost to get any specific conversion action (like a newsletter signup or app download). CAC measures the total marketing cost to acquire an actual paying customer.
- **Technical Answer:** $\text{CPA} = \frac{\text{Ad Spend}}{\text{Total Attributed Conversions}}$ where conversions can represent micro-actions (lead form, trial, add-to-cart). $\text{CAC} = \frac{\text{Total Marketing \& Sales Expenses}}{\text{Number of New Paying Customers Acquired}}$, representing full-funnel customer unit economics.

### Question 83: What is RFM Segmentation and how does MarketPilot AI use it?
- **Simple Answer:** RFM groups customers by Recency (how recently they bought), Frequency (how often they buy), and Monetary value (how much they spend). It helps identify VIP champions versus lapsed customers.
- **Technical Answer:** In `app/tools/segmentation.py`, RFM analysis constructs three quantitative vectors: (1) Recency = days since last purchase date; (2) Frequency = total purchase count; and (3) Monetary = total cumulative spend. Quantile scoring binning assigns scores from 1 to 4, segmenting users into tiers (`Champions`, `Loyal Customers`, `At Risk`, `Lost`).

### Question 84: How does K-Means Clustering segment customers in MarketPilot AI?
- **Simple Answer:** It automatically groups customers with similar spending, age, and engagement scores into clusters so marketers can target them with tailored messages.
- **Technical Answer:** In `app/agents/segmentation.py`, numeric columns are normalized using `StandardScaler` to zero mean and unit variance. `sklearn.cluster.KMeans(n_clusters=4, random_state=42)` computes cluster centroids by minimizing within-cluster sum-of-squares (inertia):
  $$\arg\min_S \sum_{i=1}^k \sum_{\mathbf{x} \in S_i} \|\mathbf{x} - \boldsymbol{\mu}_i\|^2$$
  Centroid profiles are then translated into marketing personas by the LLM.

### Question 85: What is diminishing marginal returns in digital ad spend?
- **Simple Answer:** If you double your ad budget on Instagram, your sales won't necessarily double; eventually you saturate the audience and each additional rupee produces less and less return.
- **Technical Answer:** Diminishing returns reflects concave response curves in ad spend: $R(s) = \alpha \cdot \log(1 + \beta s)$. Beyond an optimal saturation threshold, ad frequency increases, ad fatigue sets in, CPM costs rise in ad auctions, and marginal ROAS ($\frac{dR}{ds}$) decays toward zero.

### Question 86: How does MarketPilot AI formulate WHAT/WHY/EVIDENCE recommendations?
- **Simple Answer:** Every recommendation clearly states: (1) WHAT action to take; (2) WHY to take it; (3) What data EVIDENCE supports it; (4) Expected financial IMPACT; (5) Strategic RISK; and (6) Confidence score.
- **Technical Answer:** In `app/agents/optimization.py`, recommendations adhere to an immutable schema: `what` (operational directive), `why` (strategic rationale), `evidence` (specific dataset metric citation), `expected_impact` (projected lift in ROAS or CAC reduction), `risk` (potential downside or channel fatigue), and `confidence` (0.0 to 1.0 probability index).

### Question 87: What is the What-If / Scenario Simulator?
- **Simple Answer:** An interactive simulator with sliders that lets marketing executives test changes—like shifting ₹2,00,000 from Facebook to Instagram—and immediately see predicted revenue, ROAS, and risk before spending real money.
- **Technical Answer:** Exposed via `POST /api/scenario` and rendered on `frontend/scenarios.html`, the engine takes baseline allocation vectors $\mathbf{x}_{\text{current}}$ and proposed vectors $\mathbf{x}_{\text{proposed}}$. It models revenue shifts using empirical channel ROAS coefficients, validates budget constraints, calculates portfolio risk metrics, and projects net financial lift.

### Question 88: What is portfolio concentration risk in marketing budgets?
- **Simple Answer:** Putting too much money (over 50%) into a single advertising channel is dangerous because if ad costs spike or an algorithm changes, your entire business suffers.
- **Technical Answer:** Analogous to Modern Portfolio Theory (Markowitz), concentration risk measures exposure to single-channel volatility. If $\max_i(x_i / B_{\text{total}}) > 0.50$, MarketPilot AI flags a `HIGH RISK` warning for single-channel over-concentration and recommends multi-channel diversification.

### Question 89: What is the AIDA customer journey model?
- **Simple Answer:** AIDA tracks customer progression through four stages: Attention (discovering the brand), Interest (learning about the product), Desire (wanting the product), and Action (making the purchase).
- **Technical Answer:** The AIDA hierarchy-of-effects model tracks customer state transitions: Awareness $\to$ Interest $\to$ Desire $\to$ Action. MarketPilot AI's `CustomerJourneyAgent` maps event log actions to these funnel phases, measuring stage transition velocity and identifying conversion bottlenecks.

### Question 90: What is Customer Lifetime Value (CLV or LTV) and how does it relate to CAC?
- **Simple Answer:** CLV is the total profit a customer generates over their entire relationship with your brand. Healthy businesses aim for an LTV to CAC ratio of at least 3:1.
- **Technical Answer:** $\text{LTV} = \frac{\text{Average Order Value} \times \text{Purchase Frequency}}{\text{Churn Rate}} \times \text{Gross Margin \%}$. The $\text{LTV}:\text{CAC}$ ratio represents the unit-economic health of customer acquisition. A ratio of $3:1$ indicates healthy scalable acquisition; $<1:1$ indicates unsustainable value destruction; $>5:1$ indicates under-investment in growth.

---

## Category 9: n8n & Automation Workflows (Questions 91–100)

### Question 91: What is n8n and why is it used in MarketPilot AI?
- **Simple Answer:** n8n is an enterprise workflow automation platform. Once a marketing manager approves the AI's recommendations, n8n automatically syncs the data to Google Sheets, creates Google Drive folders, and emails the executive report to leadership.
- **Technical Answer:** n8n is a node-based workflow automation engine. MarketPilot AI uses it as an execution webhook target. By decoupling analytical agent reasoning from downstream operational execution, MarketPilot AI focuses on decision intelligence while n8n handles third-party API integrations (Google Workspace, Slack, CRMs, email).

### Question 92: How does the webhook integration between MarketPilot AI and n8n work?
- **Simple Answer:** When the user clicks "Approve Strategy", MarketPilot sends a secure JSON message over the internet to n8n's webhook URL, which instantly triggers the downstream automated workflow.
- **Technical Answer:** An `HTTP POST /api/jobs/{job_id}/approve` request triggers an asynchronous `httpx.AsyncClient` dispatch sending an `N8NPayload` JSON object to `settings.N8N_WEBHOOK_URL`. The payload contains `job_id`, `campaign`, `executive_summary`, `key_findings`, `recommendations`, `budget_allocation`, `confidence_score`, `approved_by`, and `report_url`.

### Question 93: What nodes exist in the `MarketPilot_n8n_workflow.json` workflow?
- **Simple Answer:** The workflow contains 9 nodes: Webhook trigger, JSON validation node, IF-condition check, Google Sheets updater, Google Drive folder uploader, Email notification dispatcher, success responder, and error handling nodes.
- **Technical Answer:** The imported workflow includes: (1) `n8n-nodes-base.webhook` (listening on `/webhook/marketpilot`); (2) `Code` node (schema validation); (3) `If` node (routing valid vs. malformed payloads); (4) `n8n-nodes-base.googleSheets` (appending rows to "MarketPilot Campaign Insights"); (5) `n8n-nodes-base.googleDrive` (saving PDF/HTML reports); (6) `n8n-nodes-base.emailSend` (HTML executive briefing dispatch); (7) `Respond to Webhook` (returning HTTP 200); and (8) Error branch exception handlers.

### Question 94: Can MarketPilot AI run if the user doesn't have an n8n account configured?
- **Simple Answer:** Yes. In `.env`, `N8N_ENABLED` defaults to `false`. The platform simulates the webhook dispatch in the UI so students can test and demonstrate the entire approval flow without needing an active n8n account.
- **Technical Answer:** In `app/api/routes.py`, the approval handler checks `if settings.N8N_ENABLED and settings.N8N_WEBHOOK_URL:`. If disabled, it sets `n8n_dispatch_status = "simulated"` and completes successfully with `HTTP 200`, returning the formatted `n8n_payload` in the response so users can inspect the exact payload in tests and demo reviews.

### Question 95: What columns are written to Google Sheets by the n8n workflow?
- **Simple Answer:** Job ID, Brand Name, Campaign Name, Execution Date, Total Budget, Confidence Score, Key Findings Summary, Recommended Budget Allocation, and Approval Status.
- **Technical Answer:** The Google Sheets integration appends a standardized row schema: `Job ID`, `Brand`, `Campaign Name`, `Timestamp`, `Budget (INR)`, `Confidence Score`, `Data Quality Score`, `Top Opportunities`, `Channel Allocation JSON`, `Approved By`, and `Report URL`.

### Question 96: How does the n8n email node format executive briefings?
- **Simple Answer:** It sends a clean, responsive HTML email containing the brand name, key findings, budget changes, and a direct clickable link to download the full campaign report.
- **Technical Answer:** The `emailSend` node renders an inline CSS template interpolating payload variables: brand name header, executive summary narrative block, key findings bullet list, budget reallocation table, and a call-to-action button linking directly to `{{$json.report_url}}`.

### Question 97: What is an idempotent webhook in automation systems?
- **Simple Answer:** It means that if an approval button is accidentally clicked twice, the system recognizes the duplicate Job ID and updates the existing record instead of creating messy duplicate entries.
- **Technical Answer:** Idempotency guarantees that identical successive requests produce the same server state: $f(f(x)) = f(x)$. In n8n and MarketPilot, webhooks carry a unique `job_id`. Downstream nodes perform upsert operations (search by `job_id` and update if present, else append), preventing duplicate sheet rows or redundant emails.

### Question 98: How do webhooks differ from polling?
- **Simple Answer:** Polling is like repeatedly asking "Is it ready yet?" every five seconds. A webhook is like giving someone your phone number and asking them to text you the moment it's finished.
- **Technical Answer:** Polling requires periodic client-initiated HTTP GET requests, consuming network bandwidth and computing cycles. Webhooks represent event-driven push architecture (Reverse APIs): the source server dispatches an HTTP POST request to the recipient's callback URL immediately when the state transition event occurs.

### Question 99: What security considerations apply to webhook endpoints?
- **Simple Answer:** Webhooks should use HTTPS encryption, secret authorization tokens, and IP address whitelisting to prevent unauthorized third parties from sending fake triggers.
- **Technical Answer:** Production webhooks require: (1) TLS 1.3 encryption in transit; (2) Shared secret HMAC signature headers (`X-MarketPilot-Signature: sha256=...`) for payload verification; (3) Replay attack mitigation via timestamp nonces; and (4) Rate-limiting reverse proxies.

### Question 100: How can n8n connect to real advertising platforms like Meta or Google Ads?
- **Simple Answer:** n8n has pre-built integration nodes for Facebook Ads and Google Ads that can automatically adjust daily ad budgets to match MarketPilot's approved recommendations.
- **Technical Answer:** n8n provides pre-built connector nodes and HTTP Request nodes for the Meta Marketing API (`POST /v18.0/{ad_set_id}`) and Google Ads REST API (`POST /v15/customers/{customer_id}/campaignBudgets`). Once authorized via OAuth2, payload allocation values can directly update `daily_budget` parameters.

---

## Category 10: Docker & Deployment (Questions 101–110)

### Question 101: What is Docker and what problem does containerization solve?
- **Simple Answer:** Docker packages our Python code, libraries, and settings into a standardized container so the project runs identically on Mac, Windows, Linux, and cloud servers without "it works on my machine" issues.
- **Technical Answer:** Docker provides operating system-level virtualization through Linux kernel namespaces and cgroups. It packages application binaries, runtime dependencies, system packages, and configuration files into an immutable container image, ensuring deterministic behavior across development and production environments.

### Question 102: Explain the structure of MarketPilot AI's `Dockerfile`.
- **Simple Answer:** It starts from a lightweight Python 3.11 image, copies `requirements.txt` to install dependencies first for fast caching, copies the application files, creates data directories, and launches Uvicorn on port 8000.
- **Technical Answer:** The `Dockerfile` uses `python:3.11-slim` as the base image. It installs essential build tools, sets `/app` as the working directory, copies `requirements.txt` to leverage Docker layer caching, executes `pip install --no-cache-dir`, copies project code, provisions persistent volume folders (`uploads`, `chroma_db`, `logs`), exposes port 8000, and specifies `CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]`.

### Question 103: What is Docker Compose and what does `docker-compose.yml` do?
- **Simple Answer:** Docker Compose is a single tool that lets you build, configure, and launch the entire application with one command: `docker compose up`.
- **Technical Answer:** Docker Compose coordinates multi-container configurations. `docker-compose.yml` specifies service build contexts, port mappings (`8000:8000`), environment variable files (`.env`), persistent volume mounts (`./uploads`, `./chroma_db`, `./data`), restart policies (`unless-stopped`), and container healthcheck intervals.

### Question 104: What is a Docker Healthcheck?
- **Simple Answer:** An automated ping that periodically checks whether the web server inside the container is alive and answering requests.
- **Technical Answer:** The `HEALTHCHECK` directive runs a diagnostic command inside the container at configured intervals (e.g., `curl -f http://localhost:8000/health || exit 1` every 30 seconds). If the endpoint fails three consecutive times, Docker flags container health as `unhealthy` and triggers automated restarts.

### Question 105: How do you deploy MarketPilot AI to Render.com?
- **Simple Answer:** Connect your GitHub repository to Render, choose "Web Service", select Docker as the runtime, set your `GOOGLE_API_KEY` in Environment Variables, and click Deploy.
- **Technical Answer:** Render deployment steps: (1) Push the repository to GitHub; (2) Create a "New Web Service" linked to the repository; (3) Select "Docker" runtime; (4) Set Region and Instance tier; (5) Configure environment variables (`PORT=8000`, `LLM_PROVIDER=gemini`, `GOOGLE_API_KEY=...`); (6) Render automatically builds the `Dockerfile` and publishes a secure HTTPS endpoint (`https://marketpilot.onrender.com`).

### Question 106: Why should the `.env` file NEVER be committed to Git?
- **Simple Answer:** The `.env` file contains secret API keys that can be stolen by internet hackers, leading to massive unauthorized credit card bills and security breaches.
- **Technical Answer:** Publicly pushing secrets triggers credential leakage. Automated scrapers monitor public repositories to extract exposed API keys within seconds. `.env` is declared in `.gitignore`, and a sanitized `.env.example` with dummy placeholders is provided for safe onboarding.

### Question 107: What is Docker layer caching and how does our `Dockerfile` optimize it?
- **Simple Answer:** Docker remembers previously completed steps. By copying and installing `requirements.txt` before copying our code, modifying code doesn't force Docker to re-download all Python packages every time.
- **Technical Answer:** Docker caches build steps sequentially. If a step's source files have not changed, Docker reuses cached filesystem layers. By copying `requirements.txt` and running `pip install` before executing `COPY . .`, application code edits invalidate only the final layer, reducing rebuild times from 5 minutes to 3 seconds.

### Question 108: What are persistent volumes in Docker?
- **Simple Answer:** Volumes are folders on the real computer that Docker links into the container so that saved uploads and databases are not lost when the container is stopped.
- **Technical Answer:** Docker container root filesystems are ephemeral; all mutations are wiped upon container destruction. Volumes mount directories on the host system directly into container mount points (`./chroma_db:/app/chroma_db`), ensuring vector embeddings and uploads persist across container lifecycles.

### Question 109: How does the application scale horizontally in a production environment?
- **Simple Answer:** By running multiple copies of the MarketPilot container behind a load balancer, with shared persistent storage for vector data.
- **Technical Answer:** Horizontal scaling deploys multiple stateless container replicas behind a reverse proxy (e.g., NGINX, AWS ALB). Local in-memory state (`JobStore`) shifts to a distributed Redis cache, and local ChromaDB files migrate to managed distributed vector databases (Chroma Cloud, Pinecone, or PostgreSQL with pgvector).

### Question 110: What is the difference between a container and a virtual machine?
- **Simple Answer:** A Virtual Machine runs an entire separate operating system with heavy overhead. A container shares the host computer's operating system kernel, making it 10x lighter and faster to start.
- **Technical Answer:** Virtual Machines use hypervisors (Type 1 or 2) to virtualize hardware, requiring complete guest operating system installations that consume gigabytes of memory and take minutes to boot. Containers isolate user spaces through Linux kernel namespaces and cgroups, sharing the host kernel with near-zero virtualization overhead and millisecond startup times.

---

## Category 11: Error Handling, Reflection & Recovery (Questions 111–115)

### Question 111: What is the Quality Governance Agent and why is it the most critical agent?
- **Simple Answer:** It acts as the chief compliance officer. It inspects the math, budget caps, and recommendations of all other agents, and has the authority to reject bad outputs and force agents to redo their work.
- **Technical Answer:** `QualityGovernanceAgent` in `app/agents/quality.py` enforces analytical rigor and brand safety. It validates hard mathematical constraints ($\sum x_i \le B_{\text{total}}$), verifies that claims correspond to input data trends, checks for tone consistency, and issues structured rejection diagnostics (`failed_agents`, `feedback`) when violations are detected.

### Question 112: Describe the complete self-healing / reflection loop in MarketPilot AI.
- **Simple Answer:** (1) Budget Agent generates an allocation; (2) Quality Agent catches an error (e.g., overspending); (3) Quality Agent rejects it and provides specific feedback; (4) Orchestrator sends the feedback back to Budget Agent; (5) Budget Agent recalculates safely; (6) Quality Agent approves the new plan.
- **Technical Answer:** The self-healing loop operates as follows:
  ```
  [Stage 3: Strategy Formulation] -> Emits Initial Budget Vector x
              │
  [Stage 4: Quality Governance] -> Evaluates Constraints: sum(x) <= B
              │
      ┌───────┴───────┐
    Pass             Fail: feedback_msg
      │               │
  Proceed to       [Orchestrator Retries]: BudgetAgent.analyze(feedback=feedback_msg)
  Synthesis           │
                   Emits Corrected Vector x_safe
                      │
                   Re-evaluated & Approved -> Proceed to Synthesis
  ```

### Question 113: How does MarketPilot AI prevent division by zero in metric calculations?
- **Simple Answer:** When a campaign has zero clicks or zero impressions, standard division would crash Python. We use safe checks to return 0.0 instead.
- **Technical Answer:** In `app/utils/helpers.py`, `safe_divide()` guards every ratio. When computing $\text{CPC} = \frac{\text{Spend}}{\text{Clicks}}$, if $\text{Clicks} = 0$, it bypasses float division and returns `0.0`. Similarly, all pandas aggregations use `.fillna(0.0)` and `.clip()` boundaries.

### Question 114: How does the system handle corrupted or missing columns in uploaded files?
- **Simple Answer:** It uses column mapping to suggest matches for close names, and if a critical column is missing, it skips that specific analysis rather than crashing the whole system.
- **Technical Answer:** Column presence is checked dynamically using schema lists (`if 'stage' in df.columns:`). Missing columns trigger automated suggestions via fuzzy string matching in `suggest_column_mapping()`. If required fields remain unavailable, the agent returns a structured warning status, allowing the orchestrator to adapt downstream prompts accordingly.

### Question 115: What error types are defined in `app/utils/errors.py`?
- **Simple Answer:** Clear, custom error classes for every failure type: DataValidationError, BudgetConstraintError, AgentExecutionError, RAGRetrievalError, and LLMProviderError.
- **Technical Answer:** We define a hierarchy of domain-specific exceptions inheriting from `MarketPilotError`:
  - `DataValidationError`: Raised when schemas violate required constraints.
  - `BudgetConstraintError`: Raised when financial allocations exceed total capital.
  - `AgentExecutionError`: Raised when an agent coroutine encounters an unrecoverable failure.
  - `RAGRetrievalError`: Raised on vector database communication failures.
  - `LLMProviderError`: Raised on model API client connection failures.

---

## Category 12: Business Value, Governance & Ethics (Questions 116–120)

### Question 116: What is the ROI and business value of MarketPilot AI for an enterprise?
- **Simple Answer:** It replaces days of tedious spreadsheet analysis with minutes of automated multi-agent intelligence, cuts ad spend waste by 15–25%, accelerates decision-making, and eliminates human math errors.
- **Technical Answer:** Business value manifests across four vectors: (1) **Operational Efficiency**: Reduces campaign post-mortem analysis time from 40 person-hours to under 60 seconds; (2) **Capital Efficiency**: Algorithmic reallocation eliminates ad spend waste in low-ROAS channels, typically boosting blended ROAS by 15–30%; (3) **Error Elimination**: Automated constraint validation prevents over-budget allocations; and (4) **Enterprise Agility**: Rapid scenario simulations allow real-time response to competitor moves.

### Question 117: What ethical risks exist in AI-driven marketing automation, and how does MarketPilot AI address them?
- **Simple Answer:** Risks include misleading claims, discriminatory customer profiling, and uncontrolled ad spending. MarketPilot AI mitigates these through Human-in-the-Loop approvals, strict data validation, and governance guardrails.
- **Technical Answer:** Key ethical risks include demographic profiling discrimination, deceptive advertising claims, and unmonitored capital deployment. MarketPilot AI enforces ethical guardrails: (1) Mandatory Human-in-the-Loop review before live execution; (2) An indexed `marketing_governance_framework.md` that penalizes non-compliant content; (3) Explicit academic synthetic data disclaimers; and (4) Demographic profiling restricted to engagement and purchasing patterns rather than sensitive personal attributes.

### Question 118: How does MarketPilot AI comply with data privacy regulations like GDPR and DPDP Act?
- **Simple Answer:** It processes anonymized customer IDs without storing sensitive personal info, allows local on-premise execution, and doesn't share customer data with third parties without authorization.
- **Technical Answer:** MarketPilot AI adheres to Privacy by Design: (1) Raw customer records use anonymized synthetic surrogate identifiers (`CUST001`); (2) Data processing occurs entirely on local application servers without transmitting customer records to external third parties; (3) Only aggregate statistical summaries are shared with LLM providers; and (4) It supports full local on-premise deployment via Docker.

### Question 119: Why is AI explainability (XAI) essential in marketing decision support?
- **Simple Answer:** Marketing directors will not risk millions of rupees on a "black box" that says "trust me." They need to understand exactly WHY the AI recommends moving budget between channels.
- **Technical Answer:** High-stakes enterprise capital allocation requires defensible auditability. Black-box recommendations invite executive skepticism and liability. MarketPilot AI enforces Explainable AI (XAI) by requiring every recommendation to include explicit `WHAT`, `WHY`, `EVIDENCE`, and `EXPECTED IMPACT` fields tied to verified dataset metrics and cited marketing frameworks.

### Question 120: How would you summarize MarketPilot AI in a 30-second elevator pitch to a Board of Directors?
- **Simple Answer:** MarketPilot AI is an autonomous AI marketing team in a box. It takes any marketing campaign, cleans its data, analyzes cross-channel performance and customer sentiment, consults proven marketing frameworks, optimizes budget allocation with mathematical safety, and automatically triggers downstream execution once an executive approves.
- **Technical Answer:** "MarketPilot AI is an enterprise-grade multi-agent decision support and automation platform for marketing performance optimization. By orchestrating a swarm of 10 specialized agents across empirical analysis, strategic synthesis, and automated quality governance, it transforms raw marketing and customer datasets into mathematically validated, RAG-grounded growth initiatives. With native human-in-the-loop controls and n8n workflow automation, it bridges the gap between deep analytics and downstream enterprise execution—delivering 20%+ ROAS efficiency with complete operational governance."
