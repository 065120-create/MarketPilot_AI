# RAG System Architecture

## Document Ingestion Pipeline
The Retrieval-Augmented Generation (RAG) system is responsible for providing agents with historical context, case studies, and brand guidelines.
1. **File Upload:** System accepts `.pdf`, `.md`, and `.txt` files.
2. **Parsing:** Extracts raw text using robust parsers (e.g., PyPDF2 or Unstructured).
3. **Metadata Extraction:** Extracts document titles, dates, and categories to allow for filtered retrieval.

## Chunking Strategy
To ensure context fits within LLM context windows and remains highly relevant:
- **Method:** Recursive Character Text Splitting.
- **Chunk Size:** 500 tokens.
- **Overlap:** 50 tokens (to preserve context across chunk boundaries).
- **Special Handling:** Markdown headers and lists are kept intact where possible to maintain structural meaning.

## Embedding Model Selection
- **Model:** `text-embedding-3-small` (OpenAI).
- **Reasoning:** Offers the best balance of cost, speed, and semantic understanding for general marketing text. Outputs 1536-dimensional vectors.

## Vector Store (ChromaDB) Setup
- **Storage:** ChromaDB is used in embedded mode, storing data locally in `./chroma_db/`.
- **Collections:** 
  - `campaign_history`: Past campaign performance reports.
  - `brand_guidelines`: Tone of voice, asset usage rules.
  - `market_research`: Competitor analysis and audience personas.

## Retrieval Strategy
- **Search Type:** Maximum Marginal Relevance (MMR) search.
- **Reasoning:** MMR ensures diversity in the retrieved chunks. Instead of returning 5 highly similar paragraphs from the same document, it retrieves relevant but distinct pieces of information.
- **Top-K:** Retrieves the top 5 chunks.

## Relevance Scoring
- **Threshold:** Distance scores above 1.5 (in L2 space) are discarded to prevent injecting irrelevant context into the prompt, which can confuse agents.
- **Re-ranking:** Agents can self-reflect on the retrieved text and ignore it if it doesn't solve their current sub-task.

## Agentic RAG (When to Retrieve)
Unlike standard RAG that retrieves data for every query, MarketPilot uses **Agentic RAG**:
- The Strategist Agent has a tool `search_knowledge_base`.
- The Agent *decides* when it needs more information (e.g., "What did we do last Black Friday?") and executes the tool dynamically.

## Source Attribution
When an agent uses retrieved context, it must cite the source file. The response schema includes:
```json
{
  "recommendation": "Allocate 40% to TikTok.",
  "sources": ["Q4_2024_Report.pdf", "TikTok_Best_Practices.md"]
}
```
This is displayed in the UI to build trust with the user.

## Knowledge Base Structure
Documents are organized as follows before ingestion:
```
/knowledge_base
  /historical
    - 2024_summer_sale.pdf
    - 2025_new_year.pdf
  /guidelines
    - brand_voice.md
    - budget_rules.txt
```
