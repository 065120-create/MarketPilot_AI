# MarketPilot AI — 5-Minute Live Academic Demo Script

**System:** MarketPilot AI (Production Version 1.0.0)  
**Presenter:** MBA / PGDM Group 6 (Aditya Mishra, Aman Kumar Singh, Hardik Srivastava, Rohit Kumar Jha, Shouvik Das, Satyam Raj)  
**Target Audience:** Evaluation Panel / Faculty / Business Executives  
**Total Duration:** 5 Minutes (300 Seconds)

---

## Act 1: Business Problem & Context (30 seconds)
- **Speaker:** "Good morning, respected professors and evaluation committee. Today, marketing organizations spend billions across fragmented channels like Google, Meta, Instagram, and YouTube. Yet, marketing directors face a severe dilemma: analytics dashboards only report *what* happened in hindsight, creative feedback is disconnected from financial ROI, and manual budget reallocation often introduces human errors or budget overruns.
- **Visual:** Open MarketPilot AI Homepage (`http://localhost:8000/` or Render URL). Show header, hero section, and system architecture summary.
- **Key Takeaway:** MarketPilot AI operates as a coordinated 10-agent autonomous marketing decision-support team that unifies deterministic financial mathematics with agentic LLM reasoning."

---

## Act 2: Create Campaign & Typo Normalization (45 seconds)
- **Speaker:** "Let's demonstrate how MarketPilot AI handles realistic, imperfect human input. I will navigate to **New Campaign**."
- **Action:** Click **[New Campaign]** in sidebar or hero banner. Enter:
  - Brand: `cocacola` (deliberate lowercase typo)
  - Campaign Name: `Share a cok — Gen Z Digital` (deliberate spelling error)
  - Target Geography: `delhi ncr, mumbai, bangalore`
  - Total Budget: `₹10,00,000` (₹10 Lakhs)
  - Click **[Check Normalization]**.
- **Visual:** Point to the **Input Verification & Normalization Modal**:
  - `cocacola` $\rightarrow$ Suggested: `Coca-Cola` (94% confidence)
  - `Share a cok...` $\rightarrow$ Suggested: `Share A Coke...` (100% confidence)
  - Location: Kept original with explicit confirmation (no fake 0% corrections).
- **Action:** Click **[Accept All Suggestions]**. The status transitions cleanly to `INPUT_VERIFICATION = COMPLETE`.
- **Speaker:** "Notice that our state machine prevents the multi-agent swarm from executing until input verification is certified. Once verified, the **[Run Multi-Agent Analysis]** button activates."

---

## Act 3: Multi-Agent Analysis & Real-Time Orchestration (45 seconds)
- **Speaker:** "Now, I click **[Run Multi-Agent Analysis]**. Watch the live agent execution pipeline."
- **Action:** Click the execution button. Navigate to **Agent Execution** (`/agents.html`).
- **Visual:** The 10 specialized agents initialize sequentially based on a dynamic dependency graph:
  1. *Validator Agent* checks dataset health (score: 87/100, fixing negative spend and whitespace).
  2. *Campaign Performance Agent* calculates true mathematical metrics across channels.
  3. *Customer Voice Agent* performs sentiment scoring on 150+ reviews.
  4. *Segmentation Agent* clusters customers using $k$-means and RFM scoring.
  5. *Customer Journey Agent* maps funnel stages from Awareness to Retention.
- **Speaker:** "Crucially, this is not a mock animation. Our FastAPI backend executes pure Python `pandas`, `numpy`, and `scikit-learn` algorithms for all numbers, ensuring arithmetic precision without LLM hallucination."

---

## Act 4: Agentic RAG Retrieval (30 seconds)
- **Speaker:** "How do the agents make strategic decisions? Through **Agentic RAG**."
- **Action:** Navigate to **RAG Explorer** (`/rag.html`).
- **Visual:** Show indexed knowledge base containing 10 authoritative marketing frameworks (KPI, Budget Allocation, Customer Journey, Governance, etc.).
- **Speaker:** "Before the Budget and Optimization agents formulate recommendations, they query our ChromaDB semantic vector store. When optimizing spend, the agent retrieves the *Marketing Budget Allocation Framework* to apply marginal return curves and portfolio concentration limits. Notice the citations in the results pane showing exact document provenance."

---

## Act 5: Quality Governance & Self-Correction Loop (30 seconds)
- **Speaker:** "Before any recommendation reaches executive review, it must pass the **Quality Governance Agent**."
- **Visual:** Point to the Quality Audit badge in the agent execution trace:
  - Total Spend Conservation: Proved $\sum B_{\text{proposed}} = ₹10,00,000$ (Variance: 0.00%).
  - Mathematical Consistency: ROAS and revenue formulas validated.
  - Evidence Check: Every claim grounded in observed channel data.
- **Speaker:** "If an LLM or sub-process attempts to allocate ₹10,50,000, the Quality Agent rejects the output, feeds back the specific arithmetic violation, and forces a re-execution loop. This guarantees 100% financial safety."

---

## Act 6: Interactive Dashboard & Analytical Insights (30 seconds)
- **Speaker:** "The analysis is complete. Let's inspect the **Campaign Dashboard** (`/dashboard.html`)."
- **Visual:**
  - KPI Cards: Predicted ROAS (3.35x), Estimated CPA (₹42.50), Predicted Conversions (2,450), Campaign Health (87/100).
  - Channel Performance Chart: Google Ads (4.0x ROAS) and Instagram (3.5x ROAS) outperforming Twitter (1.8x ROAS).
  - Customer Journey Funnel: High drop-off at Evaluation $\rightarrow$ Purchase.
  - Sentiment Breakdown: 68% Positive, 18% Neutral, 14% Negative.
- **Speaker:** "These metrics are dynamically calculated from the campaign's data—whether for Coca-Cola, Nike, or a custom user upload."

---

## Act 7: What-If Scenario Simulator (30 seconds)
- **Speaker:** "Marketers constantly ask: 'What if we shift budget?' Let's test the **Scenario Simulator** (`/scenarios.html`)."
- **Action:** Adjust the channel sliders:
  - Increase Google Ads and Instagram by ₹1,50,000.
  - Decrease underperforming Twitter and Facebook spend by ₹1,50,000.
  - Click **[Run Simulation]**.
- **Visual:** The side-by-side comparison card updates instantly:
  - Projected ROAS increases from 3.02x to 3.48x.
  - Net revenue gain: +₹4,60,000.
  - Risk Level: Low (Portfolio concentration remains under the 40% cap).
  - Budget Constraint: Valid (Exact ₹10,00,000 match).

---

## Act 8: Strategic Recommendations & Action Plan (20 seconds)
- **Speaker:** "Under **Recommendations** (`/recommendations.html`), MarketPilot AI provides an actionable 30-day tactical roadmap:
  - *Immediate Action:* Reallocate ₹1,50,000 from Twitter into Google Ads high-intent search and Instagram Reels UGC.
  - *Creative Action:* Address packaging stockouts identified by the Customer Voice Agent.
  - *Explainability:* Every recommendation includes the strategic 'Why', empirical data evidence, and RAG framework citations."

---

## Act 9: Human Approval & n8n Enterprise Automation (30 seconds)
- **Speaker:** "Finally, MarketPilot enforces strict **Human-in-the-Loop** governance. The AI proposes, but the human decides."
- **Action:** Click **[Approve Recommendations]**.
- **Visual:**
  - Status updates to `APPROVED`.
  - An outbound HTTP POST webhook is dispatched to **n8n Cloud** (`POST /webhook/marketpilot`).
  - Switch to n8n Cloud / Google Sheets tab: Show the new row instantly logged in the *MarketPilot Campaign Insights* Google Sheet with Job ID, Brand, Budget, and Recommendations.
  - Show executive email notification dispatched via Gmail to the marketing team.

---

## Act 10: Conclusion & Wrap-Up (10 seconds)
- **Speaker:** "In summary, MarketPilot AI transforms marketing operations from slow, fragmented guessing into an audited, grounded, multi-agent automated powerhouse. Our entire test suite of 69 automated tests passes with zero errors, and the system is fully cloud-deployable on Render and GitHub. Thank you, and we welcome your questions!"
