# RAG Demonstration Guide

This guide explains how to demonstrate and test the Retrieval-Augmented Generation (RAG) capabilities of MarketPilot AI.

## How to Test RAG
1. Open the MarketPilot AI UI.
2. Navigate to the **Settings** -> **Knowledge Base** section.
3. Upload a sample document. For example, create a file named `Q3_Rules.txt` with the text: 
   *"For all Q3 campaigns, we must allocate at least 20% of the budget to email marketing, and our tone should be urgent but professional."*
4. Go to the **Campaign Builder**.
5. Create a new campaign for "Q3 Product Launch" and request a strategy.

## Example Queries and Expected Results

| Query | Expected Result without RAG | Expected Result with RAG |
|-------|-----------------------------|--------------------------|
| "Create a Q3 strategy" | Generic strategy focusing on standard channels (Social, Search). | Strategy explicitly includes a minimum 20% allocation to email marketing and uses an urgent, professional tone. |
| "What was our ROI for the holiday campaign?" | "I don't have access to your historical data." | Retrieves data from `holiday_report.pdf` and states the exact ROI and key learnings. |

## How RAG Affects Recommendations
RAG grounds the LLM's vast general knowledge in your specific business context. When the Strategist Agent processes a user request, it:
1. Queries the RAG database for keywords related to the campaign.
2. Appends the retrieved text to its system prompt.
3. Formulates a plan that strictly adheres to the retrieved rules, guidelines, or historical precedents.
This prevents the agent from making generic recommendations that violate company policy.

## Viewing RAG Sources in UI
Transparency is critical. When the system generates a recommendation based on RAG:
1. Look at the bottom of the recommendation card.
2. You will see a section titled **Sources Used**.
3. Clicking on a source (e.g., `Q3_Rules.txt`) will open a modal showing the exact text snippet (chunk) that the agent retrieved and used to make its decision.
