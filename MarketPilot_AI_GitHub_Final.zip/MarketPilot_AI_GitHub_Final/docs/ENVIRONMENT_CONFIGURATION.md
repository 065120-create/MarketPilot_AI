# MarketPilot AI — Environment Configuration Reference

This document provides a comprehensive guide to every environment variable used in MarketPilot AI, based directly on `.env.example` and the application settings in `app/config.py`.

---

## 1. Quick Reference Table

| Variable Name | Required / Optional | Default Value | Usage Scope | Where to Obtain Value |
|---|---|---|---|---|
| `LLM_PROVIDER` | Optional | `gemini` | `app/config.py`, `app/agents/llm_provider.py` | Set to `gemini`, `openai`, or `anthropic`. |
| `GOOGLE_API_KEY` | Optional (Required for Gemini) | `None` | `app/agents/llm_provider.py` | [Google AI Studio](https://aistudio.google.com/app/apikey) |
| `GEMINI_MODEL` | Optional | `gemini-2.0-flash` | `app/agents/llm_provider.py` | Google Generative AI model name |
| `OPENAI_API_KEY` | Optional (Required for OpenAI) | `None` | `app/agents/llm_provider.py` | [OpenAI Platform](https://platform.openai.com/api-keys) |
| `OPENAI_MODEL` | Optional | `gpt-4o-mini` | `app/agents/llm_provider.py` | OpenAI model identifier |
| `ANTHROPIC_API_KEY` | Optional (Required for Anthropic) | `None` | `app/agents/llm_provider.py` | [Anthropic Console](https://console.anthropic.com/) |
| `ANTHROPIC_MODEL` | Optional | `claude-3-5-sonnet-20241022` | `app/agents/llm_provider.py` | Anthropic model identifier |
| `HOST` | Optional | `0.0.0.0` | `app/main.py`, Uvicorn runner | Server network binding host |
| `PORT` | Optional | `8000` | `app/main.py`, Uvicorn runner | Server network binding port (Render sets automatically) |
| `DEBUG` | Optional | `true` | Application logging | `true` or `false` |
| `LOG_LEVEL` | Optional | `INFO` | Python logging | `DEBUG`, `INFO`, `WARNING`, `ERROR` |
| `N8N_ENABLED` | Optional | `false` | `app/api/routes.py` (Approve hook) | Set to `true` when n8n webhook is active |
| `N8N_WEBHOOK_URL` | Optional (Required if n8n on) | `None` | `app/api/routes.py` | n8n Cloud Webhook Node URL |
| `CHROMA_PERSIST_DIR` | Optional | `./chroma_db` | `app/rag/vector_store.py` | Local directory for vector database persistence |
| `EMBEDDING_MODEL` | Optional | `all-MiniLM-L6-v2` | SentenceTransformers | Model name for text embeddings |
| `RAG_CHUNK_SIZE` | Optional | `500` | `app/rag/ingest.py` | Chunk size (characters/tokens) for markdown frameworks |
| `RAG_CHUNK_OVERLAP` | Optional | `50` | `app/rag/ingest.py` | Overlap between document chunks |
| `RAG_TOP_K` | Optional | `5` | `app/rag/retriever.py` | Number of framework chunks retrieved per query |
| `UPLOAD_DIR` | Optional | `./uploads` | `app/api/routes.py` | Local directory for user-uploaded CSV/XLSX files |
| `MAX_UPLOAD_SIZE_MB`| Optional | `50` | `app/api/routes.py` | Maximum file upload size limit |
| `API_KEY` | Optional | `None` | Production auth gate | User-defined secret key |

---

## 2. Operation Modes & Variable Subsets

### Mode A: Academic Demo / Zero-Key Local Mode (Default)
MarketPilot AI includes a built-in deterministic mathematical optimization engine and native vector cosine engine. It functions **100% out-of-the-box without any paid API keys**:
```ini
LLM_PROVIDER=gemini
HOST=0.0.0.0
PORT=8000
DEBUG=true
LOG_LEVEL=INFO
N8N_ENABLED=false
```

### Mode B: Full AI Synthesis Mode (Gemini Recommended)
To enable live generative LLM synthesis, configure a free or paid Google Gemini key:
```ini
LLM_PROVIDER=gemini
GOOGLE_API_KEY=AIzaSy...your_gemini_api_key_here
GEMINI_MODEL=gemini-2.0-flash
```

### Mode C: Full Autonomous Automation Mode (with n8n Cloud)
To enable downstream automation to Google Sheets, Google Drive, and Gmail:
```ini
N8N_ENABLED=true
N8N_WEBHOOK_URL=https://your-instance.app.n8n.cloud/webhook/marketpilot-webhook
```
