# MarketPilot AI — n8n Cloud Configuration & Integration Guide

This guide details the exact setup required to connect MarketPilot AI with **n8n Cloud** for autonomous downstream workflow execution (Google Sheets logging, Google Drive report archiving, and executive briefing emails).

---

## 1. Integration Architecture Overview

When a campaign recommendation is approved in MarketPilot AI (via the Human-in-the-Loop review gate on `recommendations.html` or `POST /api/jobs/{job_id}/approve`), the backend triggers an asynchronous webhook dispatch to n8n Cloud:

```
[MarketPilot AI Backend]
   │
   │ POST (JSON Payload)
   ▼
[n8n Webhook Node: /webhook/marketpilot-webhook]
   │
   ▼
[Validate JSON Node (IF)] ────────► [Webhook Response: 400 Bad Request] (If invalid)
   │ (Valid payload)
   ▼
[Google Sheets: Append Campaign Insights]
   │
   ▼
[Google Drive: Archive Report URL/Brief]
   │
   ▼
[Send Email: Dispatch Executive Briefing]
   │
   ▼
[Webhook Response: 200 Success] ──► [Returned to MarketPilot AI UI]
```

---

## 2. Step-by-Step n8n Cloud Configuration

### Step 1 — Import the Workflow
1. Log in to your instance at `https://<your-subdomain>.app.n8n.cloud`.
2. Click **Workflows** in the left sidebar &rarr; Click **Add Workflow** &rarr; Select **Import from File**.
3. Select the file:
   ```
   n8n/MarketPilot_n8n_workflow.json
   ```
4. Click **Import**. The complete canvas with 7 nodes will render automatically.

---

### Step 2 — Webhook Node Specification

- **Node Name:** `Webhook`
- **HTTP Method:** `POST`
- **Path:** `marketpilot-webhook`
- **Authentication:** `None`
- **Response Mode:** `When Last Node Finishes` (or `Using 'Respond to Webhook' Node`)
- **Expected Header:** `Content-Type: application/json`

#### Webhook URLs:
- **Test Webhook URL:**
  `https://<your-subdomain>.app.n8n.cloud/webhook-test/marketpilot-webhook`
  *(Use when testing interactively inside the n8n UI canvas by clicking "Listen for test event".)*
- **Production Webhook URL:**
  `https://<your-subdomain>.app.n8n.cloud/webhook/marketpilot-webhook`
  *(Use when the workflow is activated for live production runs.)*

#### Exact JSON Payload Sent by MarketPilot AI (`POST /api/jobs/{job_id}/approve`):
```json
{
  "job_id": "MP-2026-000001",
  "campaign": {
    "brand": "Coca-Cola",
    "campaign_name": "Share a Coke — Gen Z Digital Campaign",
    "industry": "FMCG / Beverages",
    "budget": 1000000,
    "channels": ["Instagram", "YouTube", "Google Ads", "Snapchat"]
  },
  "executive_summary": "MarketPilot AI recommends a coordinated shift in media capital (+₹1.1L to Google Ads & Instagram) and consideration-stage retargeting to plug a 35% mid-funnel conversion drop-off.",
  "key_findings": [
    "Google Ads achieved highest ROAS (4.10x) with low CPA (₹29.10)",
    "Instagram drove superior engagement with Gen Z target audience",
    "Facebook & Twitter underperformed target ROAS benchmarks"
  ],
  "recommendations": [
    {
      "what": "Shift 18% media spend to Google Ads and Instagram",
      "why": "High direct conversion efficiency and lower CPA",
      "expected_impact": "+21.4% blended revenue lift",
      "confidence": "High"
    }
  ],
  "budget_allocation": {
    "Google Ads": 320000,
    "Instagram": 280000,
    "YouTube": 180000,
    "Snapchat": 130000,
    "Facebook": 60000,
    "Twitter": 30000
  },
  "confidence_score": 91,
  "approved_by": "Authorized User",
  "approved_at": "2026-10-06T12:00:00.000000",
  "report_url": "/api/reports/MP-2026-000001"
}
```

---

### Step 3 — Google Sheets Node Configuration

- **Node Name:** `Google Sheets`
- **Operation:** `Append row in sheet`
- **Credential Required:** `Google Sheets OAuth2 API`
- **Spreadsheet:** Create or select a Google Sheet titled: `MarketPilot Campaign Audit`
- **Sheet Name:** `Sheet1`

#### Exact Column Header Mappings:
Create the following header row in Row 1 of your Google Sheet:

| Column Name | n8n Expression Value |
|---|---|
| `Job ID` | `={{ $json.body.job_id }}` |
| `Brand` | `={{ $json.body.campaign.brand }}` |
| `Campaign` | `={{ $json.body.campaign.campaign_name }}` |
| `Date` | `={{ $json.body.approved_at }}` |
| `Budget` | `={{ $json.body.campaign.budget }}` |
| `Confidence Score` | `={{ $json.body.confidence_score }}` |
| `Key Findings` | `={{ JSON.stringify($json.body.key_findings) }}` |
| `Recommendations` | `={{ JSON.stringify($json.body.recommendations) }}` |
| `Status` | `Approved` |

---

### Step 4 — Google Drive Node Configuration

- **Node Name:** `Google Drive`
- **Operation:** `File: Upload`
- **Credential Required:** `Google Drive OAuth2 API`
- **File Name:** `={{ $json.body.job_id }}_report.url`
- **File Content:** `={{ $json.body.report_url }}`
- **Destination Folder:** Select or create a folder named `MarketPilot Reports`.

---

### Step 5 — Send Email Node Configuration

- **Node Name:** `Send Email`
- **Credential Required:** `Gmail OAuth2` (or `SMTP`)
- **From Email:** Your authenticated Gmail / company address
- **To Email:** `stakeholder@company.com` (or your personal test email)
- **Subject:** `=MarketPilot Campaign Approved: {{ $json.body.campaign.campaign_name }}`
- **Email Format:** HTML
- **HTML Body Expression:**
```html
<h2>Campaign Strategy Approved & Dispatched</h2>
<p><strong>Job Identifier:</strong> {{ $json.body.job_id }}</p>
<p><strong>Brand / Campaign:</strong> {{ $json.body.campaign.brand }} — {{ $json.body.campaign.campaign_name }}</p>
<p><strong>Approved Budget:</strong> ₹{{ $json.body.campaign.budget }}</p>
<p><strong>Confidence Score:</strong> {{ $json.body.confidence_score }}%</p>
<hr>
<h3>Executive Summary</h3>
<p>{{ $json.body.executive_summary }}</p>
<hr>
<p><em>Generated autonomously by MarketPilot AI Multi-Agent Swarm.</em></p>
```

---

### Step 6 — Response Nodes

1. **Success Branch:** `Webhook Response (Success)`
   - Response Code: `200`
   - Response Body:
     ```json
     {
       "status": "success",
       "message": "Campaign data processed successfully."
     }
     ```
2. **Error Branch:** `Webhook Response (Error)`
   - Response Code: `400`
   - Response Body:
     ```json
     {
       "status": "error",
       "message": "Invalid JSON payload received."
     }
     ```

---

### Step 7 — Activation & MarketPilot Connection

1. In n8n Cloud, toggle the switch in the top right from **Inactive** to **Active**.
2. Copy the **Production URL**:
   `https://<your-subdomain>.app.n8n.cloud/webhook/marketpilot-webhook`
3. Update your MarketPilot `.env` (or Render Environment Variables):
   ```ini
   N8N_ENABLED=true
   N8N_WEBHOOK_URL=https://<your-subdomain>.app.n8n.cloud/webhook/marketpilot-webhook
   ```
4. Restart MarketPilot AI.
5. In the MarketPilot UI, navigate to `recommendations.html`, review the synthesized strategy package, and click **"Approve & Trigger n8n Workflow"**.
6. Check your Google Sheet, Google Drive, and Inbox — the automated row, file record, and email will arrive within 2 seconds.

---

## 3. Required Credentials Summary

| Credential Name | Service Type | Where Configured | Permissions Needed |
|---|---|---|---|
| `Google Sheets OAuth2` | Google Cloud API | n8n Credentials Menu | View and manage Google Sheets spreadsheets (`spreadsheets`) |
| `Google Drive OAuth2` | Google Cloud API | n8n Credentials Menu | See, create, and upload files to Google Drive (`drive.file`) |
| `Gmail OAuth2` (or SMTP) | Google Mail / SMTP | n8n Credentials Menu | Send emails on your behalf (`gmail.send`) |
